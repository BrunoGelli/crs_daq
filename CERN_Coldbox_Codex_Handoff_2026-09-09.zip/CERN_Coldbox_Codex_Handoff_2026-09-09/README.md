# CERN Coldbox Codex Handoff Bundle — 2026-09-09

Start with `docs/04_CERN_Coldbox_Context3_Codex_Handoff.md`.

This bundle contains:

- the prior mixed-LArPix software context;
- the goals/implementation document;
- the Rev5/Hijinks bench-validation addendum;
- the September 9 Codex handoff/context document;
- LArPix-v2d and LArPix-v3 datasheets;
- the scratch/bench-validation scripts that were uploaded to ChatGPT;
- the final `mixed_asic_register_test.py` used as the semantic ASIC-register regression test.

## Local-only files that should also be made available to Codex

The bundle cannot contain files that were only present on `dune01`. Before the Codex session, copy/checkpoint these from the live workspace:

```text
~/cern-coldbox/configs/pacman66_v3.json
~/cern-coldbox/configs/pacman67_v2d.json

~/cern-coldbox/worktrees/crs-fsd-run-delay/iog_1-tile_7-hydra-network.json
    (or wherever that successful v2d network JSON was written)

current ~/cern-coldbox/worktrees/crs-cern/RUN_CONFIG.json
current CERN io/pacman*.json files
any locally modified donor files used during the successful tests
```

Also checkpoint both repositories before Codex edits them:

```bash
cd ~/cern-coldbox/worktrees/crs-cern
git status --short
git diff
git rev-parse HEAD
git branch --show-current

cd ~/cern-coldbox/src/larpix-control
git status --short
git diff
git rev-parse HEAD
git branch --show-current
```

The successful bench software state is more important than a historical remote branch head. Commit local changes used by the successful tests before broad codebase modifications.

## Important warning

`scratch/pacman-tests/probe_larpix_hijinks.py.` is a real uploaded filename with a trailing period. It was created accidentally during bench work and contains a newer mapped-Hijinks probe than the similarly named no-dot file. Do not confuse the two.
