# CERN Coldbox Mixed LArPix v2d / v3a
## Context 3 — Bench-Proven Behavior and Codebase Handoff for Codex

**Date:** September 9, 2026  
**Project:** CERN Coldbox LArPix test  
**Purpose:** Consolidate the September 8 bench validation into an implementation handoff for fixing a single `crs_daq` codebase.

---

# 0. How to use this document

This document is the third context document for the CERN mixed-LArPix effort.

It should be read together with:

1. `CERN_Coldbox_Mixed_LArPix_Context.md`
2. `CERN_Coldbox_Mixed_LArPix_Goals_Implementation.md`
3. `CERN Coldbox Mixed LArPix — Hijinks - Rev5 Bench Validation Addendum.md`

However, **this document supersedes earlier statements where the bench state has changed**. In particular:

- the v2d tile has now been located;
- the v2d Rev5/Hijinks communication path has now been demonstrated;
- a full v2d Hydra discovery has succeeded through the three live external links;
- one standalone Python script has successfully read, written, read back, and restored real ASIC configuration registers on both a v2d ASIC and a v3 ASIC using the same `larpix-control` installation;
- the correct separation between PACMAN packet family and ASIC configuration/register family has now been demonstrated on hardware.

For implementation decisions, use the following precedence:

```text
1. Bench-proven behavior and successful scripts/results in this document
2. Current local larpix-control checkout actually used on dune01
3. Proven donor branches: fsd-run-delay and v3_10x16
4. 2x2-run3-cooldown high-level workflow
5. Older assumptions in the previous context documents
```

The goal for Codex is **not** to redesign the DAQ. The goal is to make one CERN `crs_daq` implementation correctly use the capabilities that already exist.

---

# 1. Executive conclusion

We now have enough bench evidence to proceed with a codebase-wide CERN adaptation.

The central result is:

> **One `larpix-control` installation can correctly operate LArPix-v2d and LArPix-v3 ASICs, including genuinely different ASIC register maps, as long as each homogeneous PACMAN control connection is constructed with the correct packet family and each `Chip` is constructed with the correct ASIC configuration version.**

The successful abstraction is:

```text
high-level CRS_DAQ semantic operation
        |
        | e.g. chip.config.digital_monitor_chan = 1
        v
larpix-control Chip
        |
        +---- version="2d" --> Configuration_v2d --> correct v2d register address
        |
        +---- version=3    --> Configuration_v3  --> correct v3 register address
        |
        v
family-correct configuration packet
        |
        +---- v2d --> Packet_v2
        |
        +---- v3  --> Packet_v3
        |
        v
PACMAN_IO for that homogeneous PACMAN
        |
        v
Rev5 / Hijinks
```

The control architecture should therefore remain:

```text
one source tree
one common high-level CRS_DAQ workflow

but

one homogeneous Controller/PACMAN_IO process per PACMAN/io_group
```

There is **no requirement for two permanent CRS_DAQ implementations**.

There is also no need for high-level CRS_DAQ code to manually know that, for example, `digital_monitor_chan` is register 119 in v2d but register 115 in v3. `larpix-control` already knows this.

The principal CERN porting work is therefore:

1. make `RUN_CONFIG.json` describe the real CERN hardware and ASIC families;
2. make all Rev5/Hijinks PACMAN operations use the correct logical-channel / physical-UART model;
3. make v2d and v3 Hydra discovery run from the same CERN source tree and accept explicit PACMAN configs;
4. make `network_larpix.py`, `configure_larpix.py`, and the shell orchestration select the correct packet/configuration family per IOG;
5. preserve ASIC version metadata when writing and loading configuration files;
6. keep mixed acquisition raw and verify `record_data.py` does not parse payloads;
7. audit the remaining 2x2 codebase for assumptions that are valid only for v2b/old PACMANs or only for v3.

---

# 2. Current bench hardware mapping — now established

## 2.1 PACMAN #67 — v2d

```text
PACMAN:          #67
IP:              192.168.0.103
io_group:        1
ASIC family:     LArPix-v2d
Chip version:    "2d"
PACMAN packet:   2 / Packet_v2
Rev5 tile slot:  7
```

Known-good bench power recipe:

```text
VDDA_DAC = 48092
VDDD_DAC = 32838
```

Observed loaded readback was approximately:

```text
VDDA ≈ 2.000 V
IDDA ≈ 0.73–0.80 A

VDDD ≈ 1.412 V
IDDD ≈ 0.57 A
```

This is the current **bench-proven** recipe. It should be treated as the working CERN test value, not necessarily as a statement about the eventual final operating point.

The tile was found by scanning Rev5 power ports. Tile slots 1–6 and 8–10 were effectively unloaded; slot 7 showed the real tile load.

## 2.2 PACMAN #66 — v3

```text
PACMAN:          #66
IP:              192.168.0.102
io_group:        2
ASIC family:     LArPix-v3 / CERN v3a hardware
Software family: 3
PACMAN packet:   3 / Packet_v3
Rev5 tile slot:  10
```

Known-good bench power recipe:

```text
VDDA_DAC = 52000
VDDD_DAC = 28000
```

Observed loaded readback:

```text
VDDA ≈ 2.148–2.149 V
IDDA ≈ 0.815 A

VDDD ≈ 1.227–1.228 V
IDDD ≈ 0.498 A
```

The software representation is currently `3`, not `"3a"`. Do not invent a new `"3a"` configuration version unless a real software-level v3a distinction is identified.

---

# 3. Hijinks logical channels and physical UARTs

Hijinks exposes 40 logical LArPix channels while the PACMAN has 32 physical UART engines.

The mapping is:

```text
 logical   physical
 ------------------
  1  ->  1
  2  ->  2
  3  ->  3
  4  ->  4

  5  ->  5
  6  ->  6
  7  ->  7
  8  ->  8

  9  ->  9
 10  -> 10
 11  -> 11
 12  -> dead

 13  -> 12
 14  -> 13
 15  -> 14
 16  -> dead

 17  -> 15
 18  -> 16
 19  -> 17
 20  -> dead

 21  -> 18
 22  -> 19
 23  -> 20
 24  -> dead

 25  -> 21
 26  -> 22
 27  -> 23
 28  -> dead

 29  -> 24
 30  -> 25
 31  -> 26
 32  -> dead

 33  -> 27
 34  -> 28
 35  -> 29
 36  -> dead

 37  -> 30
 38  -> 31
 39  -> 32
 40  -> dead
```

Dead logical channels:

```text
12, 16, 20, 24, 28, 32, 36, 40
```

This distinction is non-negotiable:

```text
LArPix Chip Key / packet io_channel:
    logical channel

low-level Rev5 PACMAN UART registers:
    physical UART
```

Example:

```text
Key(2, 37, 1)
```

must remain logical channel 37.

Hijinks maps the outgoing command internally:

```text
logical 37 -> physical UART 30
```

But PACMAN RX mask, UART clock ratio, and packet-delay operations must use physical UART 30.

Never replace:

```text
Key(2, 37, 1)
```

with:

```text
Key(2, 30, 1)
```

---

# 4. Rev5/Hijinks PACMAN behavior that has been bench-proven

The following PACMAN behavior is no longer speculative.

## 4.1 Physical RX mask

PACMAN register:

```text
0x201c
```

is an active-low 32-bit physical-UART receive mask.

```text
bit = 1 -> physical UART disabled
bit = 0 -> physical UART enabled
```

Therefore:

```text
0xffffffff
```

disables all receive UARTs.

For physical UART `N`:

```python
mask = 0xffffffff & ~(1 << (N - 1))
```

Examples:

```text
logical 27 -> physical 23 -> RX mask 0xffbfffff
logical 37 -> physical 30 -> RX mask 0xdfffffff
```

Enabling many unused physical UARTs can produce large quantities of garbage-looking DATA traffic. Do not use "all RX enabled" as a normal state.

## 4.2 Packet-delay register

The packet-delay register is indexed by **physical UART**, not logical channel.

The working tests use packet delay:

```text
0xff
```

on the selected physical UART.

## 4.3 v3 UART clock ratio

For v3, the successful path explicitly sets:

```python
set_uart_clock_ratio(physical_uart, 1)
```

For:

```text
logical 37 -> physical 30
```

the successful test used:

```text
UART 30 clock ratio = 1
```

This is family/physical-layer behavior and should be implemented centrally in Rev5/Hijinks PACMAN setup rather than copied into many high-level scripts.

## 4.4 Rev5 power state

The working scripts established and verified:

```text
Tile Enable         0x0010
Global power        0x0014
MCLK                0x1010
physical RX mask    0x201c
```

and the Rev5 DAC/ADC power registers used by the donor branches.

The existing bench tools are authoritative references:

```text
power_off_rev5.py
power_tile_rev5.py
scan_rev5_power_ports.py
```

---

# 5. v3 root communication — exact bench-proven recipe

The known-good diagnostic is:

```text
scratch/pacman-tests/bootstrap_v3_root_hijinks.py
```

Known-good target:

```text
PACMAN #66
IOG 2
tile 10
logical channel 37
physical UART 30
chip ID 1
ASIC version 3
```

Successful sequence:

```text
1. Tile already powered.

2. Disable all PACMAN RX:
       0x201c = 0xffffffff

3. logical 37 -> physical UART 30

4. UART 30 clock ratio = 1

5. UART 30 packet delay = 0xff

6. Hard reset LArPix

7. Create:
       Key(2, 37, 1)
       version = 3

8. Bootstrap root communication:
       i_rx0..3          = 3
       r_term0..3        = 7
       v_cm_lvds_tx0..3  = 5

       enable_posi              = [0,0,0,1]
       i_tx_diff2               = 7
       tx_slices2               = 15
       enable_piso_downstream   = [0,0,1,0]
       enable_piso_upstream     = [0,0,0,0]

9. Enable physical RX UART 30:
       0x201c = 0xdfffffff

10. CONFIG_READ:
       chip ID 1
       ASIC register 122 = chip_id

11. Receive exact reply.
```

Observed successful reply:

```text
Key:       2-37-1
Packet:    Packet_v3
Type:      CONFIG_READ
Register:  122
Value:     1
Parity:    valid
```

A raw-sniffer control run saw:

```text
DATA ch=37 ts=2314986 payload=07e8051c39412542
```

This raw word was the same real configuration reply that the high-level parser decoded.

---

# 6. Why an immediate post-reset read failed

A major debugging lesson is that:

```text
hard reset
-> immediately CONFIG_READ
```

is not a valid generic root-communication test.

A freshly reset root may not yet have an enabled downstream PISO return path.

The simple scratch probe:

```text
probe_larpix_hijinks.py.
```

performed approximately:

```text
hard reset
enable PACMAN RX
CONFIG_READ
```

and therefore saw no ASIC DATA reply.

That failure did **not** demonstrate a Packet_v2 parsing problem.

The correct generic shape is:

```text
hard reset
-> send CONFIG_WRITEs that establish the root communication path
-> enable the correct PACMAN physical RX UART
-> CONFIG_READ / reconciliation
```

This applies conceptually to both families, while the actual root analog/UART configuration values remain family-specific.

---

# 7. v2d Hydra discovery — now demonstrated successfully

The original attempt to run FSD `hydra_v2b.py` hung before talking to the CERN PACMAN because the donor instantiated `PACMAN_IO` with its default:

```text
io/pacman.json
```

which pointed to the FSD hardware, not CERN.

This was an important integration lesson:

> **Every CERN control/discovery path must take or derive an explicit PACMAN config and must not silently fall back to a donor branch's `io/pacman.json`.**

After correcting the PACMAN configuration, the FSD v2d Hydra path successfully ran against CERN PACMAN #67.

Initial root results:

```text
1-25-21   configured
1-26-61   configured
1-27-101  configured
1-28-151  NOT configured
```

This matches Hijinks:

```text
logical 25 -> physical UART 21
logical 26 -> physical UART 22
logical 27 -> physical UART 23
logical 28 -> dead
```

The fourth external root failure is therefore expected.

The discovery continued through the remaining three roots, resolved the waitlist iteratively, and ended with:

```text
*****RE-TESTING  0 CHIPS
[]

0 NON-CONFIGURED chips
[]
```

The output network contained:

```text
25 -> ext, root 21, ...
26 -> ext, root 61, ...
27 -> ext, root 101, ...
28 -> ext only
```

and was written as:

```text
iog_1-tile_7-hydra-network.json
```

This is strong hardware evidence that the v2d tile/network is healthy and that the software can route around the Hijinks-dead fourth external link.

---

# 8. Raw v2d traffic proved that parsing was not the problem

Before running the correct bootstrap/networking path, the v2d raw sniffer saw only PACMAN-generated SYNC/HEARTBEAT words.

After the correct v2d Hydra setup, the sniffer saw many genuine PACMAN DATA words on logical channel 27, for example:

```text
DATA ch=27 ts=6889644 payload=a73e031c394125c2
DATA ch=27 ts=6891400 payload=a742031c39412542
DATA ch=27 ts=6893156 payload=a746031c394125c2
...
```

These are real configuration-read replies generated while the FSD networking code was reconciling the ASIC configuration.

This established:

```text
v2d CONFIG packet
-> PACMAN #67 TX
-> Hijinks
-> v2d ASIC network
-> downstream reply
-> PACMAN DATA word
-> dataserver
```

Therefore the earlier "no reply" was not caused by a hidden alternative v2d PACMAN reply format.

---

# 9. Most important new proof: one code path used two real ASIC register maps

The key validation script is:

```text
scratch/pacman-tests/mixed_asic_register_test.py
```

This script intentionally used `larpix-control` directly rather than hiding behavior inside CRS_DAQ.

It tested:

```text
PACMAN67 / v2d:
    Key(1, 27, 101)
    Chip version = "2d"
    PACMAN_IO asic_version = 2

PACMAN66 / v3:
    Key(2, 37, 1)
    Chip version = 3
    PACMAN_IO asic_version = 3
```

It did not hard-reset either target; both communication paths were already established.

## 9.1 Critical software distinction

There are two independent version choices:

### Chip / ASIC configuration version

```python
c.add_chip(key, version="2d")
```

creates:

```text
Configuration_v2d
```

while:

```python
c.add_chip(key, version=3)
```

creates:

```text
Configuration_v3
```

This controls:

```text
ASIC register names
ASIC register addresses
bit locations
default configuration
semantic properties
```

### PACMAN packet family

```python
PACMAN_IO(..., asic_version=2)
```

uses the v2 packet family for the homogeneous v2d PACMAN.

```python
PACMAN_IO(..., asic_version=3)
```

uses the v3 packet family for the homogeneous v3 PACMAN.

This controls packet serialization/parsing at the PACMAN I/O layer.

These two concepts must not be conflated.

---

# 10. `larpix-control` already translates semantic ASIC settings

The test deliberately chose settings that prove real register-map differences.

The semantic property:

```text
digital_monitor_chan
```

lives at:

```text
v2d -> ASIC register 119
v3  -> ASIC register 115
```

Likewise:

```text
digital_monitor_enable:
    v2d -> ASIC register 118
    v3  -> ASIC register 114
```

while:

```text
enable_hit_veto:
    v2d -> ASIC register 128 bit 6
    v3  -> ASIC register 128 bit 6
```

This means high-level code should write:

```python
chip.config.digital_monitor_chan = 1
```

rather than:

```python
if v2d:
    register = 119
elif v3:
    register = 115
```

The physical-register translation belongs to:

```text
Configuration_v2d
Configuration_v3
```

inside `larpix-control`.

This is one of the most important architectural conclusions for the CRS_DAQ port.

---

# 11. Exact mixed ASIC register validation result

## 11.1 PACMAN #67 / v2d

Software resolved:

```text
ASIC config class:        Configuration_v2d
PACMAN packet family:     2

enable_hit_veto:          ASIC reg 128
digital_monitor_enable:   ASIC reg 118
digital_monitor_chan:     ASIC reg 119
```

Real ASIC reads:

```text
ASIC register 128 -> 0x60
Packet_v2
raw=9701821d39412542

bit 6 -> enable_hit_veto = 1
semantic Configuration_v2d decode -> 1
```

Digital-monitor enable:

```text
ASIC register 118 -> 0x00
Packet_v2
raw=97d9011c39412542
```

Family-specific write/read/restore:

```text
ASIC register 119:
    initial = 0x00
    semantic digital_monitor_chan = 0

set:
    cfg.digital_monitor_chan = 1

readback:
    ASIC register 119 -> 0x01
    raw=97dd051c39412542
    semantic decode = 1

restore:
    ASIC register 119 -> 0x00
    raw=97dd011c394125c2
    semantic decode = 0
```

Result:

```text
PASS: PACMAN67 / v2d ASIC register access works
```

## 11.2 PACMAN #66 / v3

Software resolved:

```text
ASIC config class:        Configuration_v3
PACMAN packet family:     3

enable_hit_veto:          ASIC reg 128
digital_monitor_enable:   ASIC reg 114
digital_monitor_chan:     ASIC reg 115
```

Real ASIC reads:

```text
ASIC register 128 -> 0x60
Packet_v3
raw=0700821d394125c2

bit 6 -> enable_hit_veto = 1
semantic Configuration_v3 decode -> 1
```

Digital-monitor enable:

```text
ASIC register 114 -> 0x00
Packet_v3
raw=07c8011c39412542
```

Family-specific write/read/restore:

```text
ASIC register 115:
    initial = 0x00
    semantic digital_monitor_chan = 0

set:
    cfg.digital_monitor_chan = 1

readback:
    ASIC register 115 -> 0x01
    raw=07cc051c39412542
    semantic decode = 1

restore:
    ASIC register 115 -> 0x00
    raw=07cc011c394125c2
    semantic decode = 0
```

Result:

```text
PASS: PACMAN66 / v3 ASIC register access works
```

Final result:

```text
PASS: BOTH ASIC FAMILIES READ / WRITE / RESTORE SUCCESSFULLY
```

---

# 12. What the mixed register test proves

The successful chain was:

```text
same Python source
same local larpix-control installation
        |
        +------------------------------+
        |                              |
        v                              v
Chip(version="2d")                 Chip(version=3)
        |                              |
Configuration_v2d                 Configuration_v3
        |                              |
reg 119 for monitor chan          reg 115 for monitor chan
        |                              |
Packet_v2                         Packet_v3
        |                              |
PACMAN #67                        PACMAN #66
        |                              |
real v2d ASIC                     real v3 ASIC
        |                              |
write 0 -> 1 -> 0                 write 0 -> 1 -> 0
        |                              |
verified by readback              verified by readback
```

This proves that we do **not** need to duplicate normal high-level ASIC configuration code merely because the v2d and v3 physical register maps differ.

The `larpix-control` `Chip` + `Configuration_*` abstraction already handles that translation.

This should guide the CERN CRS_DAQ conversion:

> **Prefer semantic configuration properties everywhere. Remove or family-guard raw ASIC-register assumptions. Let `larpix-control` own ASIC register-space differences.**

---

# 13. What this does NOT prove

The test did **not** demonstrate one single `PACMAN_IO` object parsing both families simultaneously.

The current `PACMAN_IO` has one:

```text
asic_version
```

for the instance.

The mixed test used the same code but created/used a homogeneous I/O instance for each target.

This is fine and matches the CERN hardware:

```text
one PACMAN = one ASIC family
```

The intended production architecture remains:

```text
same source tree

process for PACMAN / IOG 1:
    homogeneous v2d
    PACMAN_IO(asic_version=2)

process for PACMAN / IOG 2:
    homogeneous v3
    PACMAN_IO(asic_version=3)

...
```

Do not redesign `PACMAN_IO` for mixed live parsing unless a future requirement actually needs it.

---

# 14. Configuration packet compatibility vs data packet incompatibility

The v2d and v3 configuration packet layouts are compatible at the wire level:

```text
packet declaration
chip ID
register address
register data
magic word 0x89504E47
downstream marker
parity
```

This is why the high-level configuration path can be so similar.

However, **normal DATA packets are not the same**.

Important differences include:

```text
v2d:
    data packet declaration 00
    8-bit ADC
    older timestamp/data layout

v3:
    data packet declaration 01
    10-bit ADC
    CDS/reset-sample fields
    different timestamp/data layout
```

Therefore:

```text
configuration/control:
    family-aware but highly shareable

raw recording:
    can be family-agnostic

decoded data:
    must be family-aware
```

---

# 15. CRS_DAQ porting model

Use:

```text
2x2-run3-cooldown
```

as the high-level workflow model.

Use:

```text
fsd-run-delay
```

as the strongest v2d donor/reference.

Use:

```text
v3_10x16
```

as the strongest v3 + Rev5/Hijinks donor/reference.

Do not treat any donor branch as something that should remain a separate production installation.

The end state should be:

```text
one CERN crs_daq branch/worktree
        |
        +-- shared RUN_CONFIG / config loader / run scripts
        +-- shared Rev5/Hijinks pacman_base
        +-- family-dispatched Hydra discovery
        +-- family-dispatched homogeneous PACMAN_IO construction
        +-- shared high-level configuration scripts
        +-- shared raw recorder
```

Family-specific Hydra code may remain separate internally where the ASIC physical layer genuinely differs.

---

# 16. Codebase-wide tasks for Codex

The following is the requested implementation scope.

## 16.1 `RUN_CONFIG.json`

Make `RUN_CONFIG.json` authoritative for:

```text
io_group -> ASIC family
io_group -> PACMAN generation
io_group -> tile list
per-tile power DACs
exclusions
paths used by config/networking
```

For the current two-PACMAN bench, the known facts are:

```text
IOG 1:
    ASIC = "2d"
    PACMAN #67
    IP = 192.168.0.103
    active tile = 7

IOG 2:
    ASIC = 3
    PACMAN #66
    IP = 192.168.0.102
    active tile = 10
```

Known active-tile power values:

```text
IOG 1 / tile 7 / v2d:
    VDDA_DAC = 48092
    VDDD_DAC = 32838

IOG 2 / tile 10 / v3:
    VDDA_DAC = 52000
    VDDD_DAC = 28000
```

Do not guess the eventual six-PACMAN assignment from the approximate project counts. Make the structure scalable, but only encode real hardware assignments that are known.

## 16.2 PACMAN config files

Control/config/networking should use one PACMAN per config, for example:

```text
io/pacman_io1.json
io/pacman_io2.json
...
```

For the current bench:

```text
pacman_io1:
    IOG 1 -> 192.168.0.103

pacman_io2:
    IOG 2 -> 192.168.0.102
```

An aggregate:

```text
io/pacman.json
```

can contain both/all PACMANs for raw data recording.

All functions that instantiate a control `PACMAN_IO` must use the explicit config passed to the command. Do not silently fall back to a donor branch's default `io/pacman.json`.

## 16.3 Common family helper

There should be one source of truth for mapping ASIC family to PACMAN packet family.

Conceptually:

```python
def asic_to_packet_version(asic_version):
    if asic_version in ("2d", "2b", 2):
        return 2
    if asic_version == 3:
        return 3
    raise ValueError(...)
```

For CERN, the required cases are:

```text
"2d" -> 2
3    -> 3
```

Do not scatter this mapping through many scripts.

## 16.4 `base/pacman_base.py`

This is one of the most important CERN conversion points.

It should centralize Rev5/Hijinks behavior:

```text
logical channel -> physical UART
dead Hijinks logical channels
physical RX mask at 0x201c
packet delay indexed by physical UART
v3 clock-ratio handling
Rev5 power registers
Rev5 reset/clock handling
```

High-level scripts should continue to call semantic helpers such as:

```python
enable_pacman_uart_from_io_channel(...)
disable_all_pacman_uart(...)
```

without reimplementing masks locally.

Any old 2x2 behavior that directly treats logical `io_channel` as the hardware RX-mask bit must be removed or isolated from the CERN Rev5 path.

## 16.5 Hydra discovery scripts

Provide CERN versions, conceptually:

```text
hydra_v2d.py
hydra_v3.py
```

They should live in the same source tree and use the same current `larpix-control` installation.

They may remain family-specific internally because root/UART setup differs.

Requirements:

```text
- accept explicit --pacman_config or equivalent;
- derive/check ASIC family from RUN_CONFIG;
- construct PACMAN_IO with the correct packet family;
- use logical channels in Chip Keys;
- use physical UARTs only through pacman_base;
- tolerate the Hijinks-dead fourth channel;
- save network JSONs in the normal CRS_DAQ format;
- create Chips with the correct ASIC version;
- do not import a donor branch's local hardware configuration by accident.
```

Bench acceptance references:

```text
v2d tile 7:
    roots 21 / 61 / 101 succeeded
    logical 28 root failed as expected
    discovery ended with 0 non-configured chips

v3:
    logical 37 / physical UART 30 root communication is proven
```

The existing donor names (`hydra_v2b.py`, `network_base_FSD.py`) can be cleaned up for CERN if useful, but correctness is more important than naming.

## 16.6 `network_larpix.py`

This should dispatch using:

```text
io_group_asic_version_[io_group]
```

and keep each invocation homogeneous.

Important fix from the donor code:

> Do not retain a final/enforcement `PACMAN_IO(..., asic_version=3)` that is globally hardcoded.

For a one-IOG PACMAN config:

```text
read IOG
-> read ASIC family from RUN_CONFIG
-> map family to packet version
-> construct homogeneous PACMAN_IO
-> load correct network/config objects
-> enforce
```

Networking should save ASIC configuration files with the real ASIC version.

The existing `config_loader.write_config_to_file()` already writes:

```text
meta.ASIC_VERSION
```

and `load_config_from_file()` uses that value when it calls:

```python
c.add_chip(chip_key, version=version)
```

Preserve this behavior.

## 16.7 `run/iog/network.sh`

The existing 2x2 `run/iog/network.sh` is structurally close to what CERN needs because it already launches one `network_larpix.py` process per IOG with a separate `io/pacman_ioN.json`.

Adapt it for the CERN IOG count/names and remove module/TPC assumptions that do not apply.

Desired behavior:

```text
network one IOG:
    ./run/iog/network.sh 1

network several/all:
    launch one homogeneous process per requested IOG
```

Each job must:

```text
- pass the correct one-PACMAN config;
- use the correct controller/network config;
- write ASIC configs with correct ASIC_VERSION metadata;
- keep logs/PIDs clearly associated with the IOG.
```

## 16.8 `configure_larpix.py`

The old high-level structure is reusable.

Main required fix:

```text
one-PACMAN config
-> determine IOG
-> determine ASIC family
-> packet family = asic_to_packet_version(...)
-> construct PACMAN_IO with that family
-> load ASIC config files
-> enforce
```

Do not manually translate ASIC register numbers.

Once a config file is loaded with:

```text
ASIC_VERSION = "2d"
```

or:

```text
ASIC_VERSION = 3
```

`larpix-control` should create the corresponding `Configuration_v2d` or `Configuration_v3`.

This is exactly the behavior proven by `mixed_asic_register_test.py`.

## 16.9 `run/iog/configure.sh`

The existing 2x2 script already follows the desired process model:

```text
one configure_larpix.py process per IOG
```

Adapt it to the CERN IOG/config directory organization.

It should not need family-specific register logic in Bash.

The family decision belongs inside Python via `RUN_CONFIG`.

## 16.10 `record_data.py` and raw acquisition

This must be checked carefully, but the current raw architecture is promising.

The existing raw path in `utility_base.data()` does:

```python
c.io.disable_packet_parsing = True
c.io.enable_raw_file_writing = True
```

and writes PACMAN messages to the raw HDF5.

That is exactly the desired mixed-family architecture.

Important:

```text
DO NOT use --packet for the mixed run.
```

The parsed branch currently constructs:

```text
HDF5Logger(..., version="3.0")
```

which is explicitly v3-oriented and is not a mixed-family representation.

For raw mode, `record_data.py` can use one aggregate PACMAN config and listen to both/all dataservers because the acquisition path does not need to decode the 8-byte ASIC payload.

The current `PACMAN_IO` constructor still requires an `asic_version`; if raw parsing is immediately disabled, a temporary/dummy family may remain necessary. Codex should verify by tracing the exact local implementation rather than changing this constructor just for aesthetics.

Acceptance test:

```text
record 10–30 s from PACMAN #66 + #67
verify raw HDF5 contains messages from IOG 1 and IOG 2
verify source io_group is preserved
offline-decode each source with its family
```

---

# 17. High-priority code audit patterns

Codex should grep the full CERN source tree for assumptions that can silently break mixed-family operation.

At minimum search for:

```text
asic_version=3
asic_version = 3
Packet_v2
Packet_v3
isinstance(...Packet_v2...)
isinstance(...Packet_v3...)
test_mode_uart
register 0x18
set_reg(0x18
0x201c
add_chip(
HDF5Logger
version="3.0"
io/pacman.json
PACMAN_IO(
enable_miso_
enable_mosi
```

Specific known risks:

## 17.1 Hardcoded packet family

Any control path with:

```python
PACMAN_IO(..., asic_version=3)
```

must be reviewed.

## 17.2 `add_chip()` without `version`

`larpix-control` defaults `Chip` construction to version 2.

Therefore code like:

```python
c.add_chip(key)
```

is potentially wrong for both CERN families.

Every dynamically created real/broadcast chip used for semantic configuration should be reviewed and given the correct version where required.

## 17.3 Hardcoded Packet class checks

Helpers that do:

```python
isinstance(pkt, Packet_v2)
```

or only accept `Packet_v3` should be made family-safe where they are used by shared code.

Prefer packet-interface properties where possible:

```text
packet_type
register_address
register_data
chip_id
has_valid_parity()
```

rather than class-specific checks.

## 17.4 `test_mode_uart*`

This is a particularly dangerous example of why ASIC register space matters.

v2d `larpix-control` exposes the UART test-mode configuration.

v3 has a different register map and does not use those fields in the same way.

Any legacy helper that blindly writes:

```text
test_mode_uart0
test_mode_uart1
test_mode_uart2
test_mode_uart3
```

must be family-guarded or redesigned.

Do not assume the same raw register address means the same semantic function.

## 17.5 Old logical RX-mask register handling

Legacy code such as:

```python
io.set_reg(0x18, 2**(io_channel-1), ...)
```

must not be used as the CERN Rev5/Hijinks receive-enable implementation.

The bench-proven path is:

```text
logical IO channel
-> Hijinks mapping
-> physical UART
-> active-low mask at 0x201c
```

## 17.6 Parsed HDF5 hardcoded to v3

Any mixed run using:

```text
HDF5Logger(version="3.0")
```

is not the intended first-pass acquisition.

Use raw mode.

---

# 18. Important family-specific behavior that should remain family-specific

The goal is not to erase all differences between v2d and v3.

Hydra/root physical-layer settings are legitimately different.

## v2d donor behavior

The FSD v2d path uses v2d-specific receiver/transmitter settings and configuration semantics.

The proven CERN result came from the FSD path after it was pointed at PACMAN #67.

Preserve the proven algorithm first; clean it up only after the CERN path is stable.

## v3 donor behavior

The v3 root path includes:

```text
v_cm_lvds_tx
v3-specific i_rx/r_term values
physical UART clock ratio = 1
```

and other v3-specific physical-layer behavior.

These differences can live behind:

```text
network_v2d(...)
network_v3(...)
```

or equivalent family-specific functions.

After Hydra networking is complete, normal semantic ASIC configuration should converge onto the common `larpix-control` interface.

---

# 19. Existing high-level CRS_DAQ pieces that should be reused

The 2x2 workflow already provides useful structure:

```text
RUN_CONFIG.json
config_loader
network_larpix.py
configure_larpix.py
run/iog/network.sh
run/iog/configure.sh
configuration path tracking
PID/process orchestration
archiving
record_data.py
raw HDF5 writer
```

The existing `run/iog` model is especially useful:

```text
one process per IOG
```

That is exactly the partition required by the homogeneous-PACMAN rule.

Do not collapse all IOGs into one parsed control `PACMAN_IO`.

---

# 20. Local `larpix-control` is part of the implementation baseline

The successful tests ran against:

```text
/home/bgelli/cern-coldbox/src/larpix-control
```

Codex must inspect the **current local checkout**, not only infer behavior from a historical remote branch/commit.

The current local implementation used in the successful test supports:

```text
Configuration_v2d
Configuration_v3
Packet_v2
Packet_v3
Chip(version="2d")
Chip(version=3)
PACMAN_IO(..., asic_version=2)
PACMAN_IO(..., asic_version=3)
```

and correct v2d/v3 magic-word configuration packet generation.

Before Codex makes broad changes, any local modifications in this `larpix-control` tree should be checkpointed/committed separately so the exact successful software state is reproducible.

The first CERN milestone should avoid invasive changes to:

```text
larpix/packet/packet_v2.py
larpix/packet/packet_v3.py
larpix/configuration/configuration_v2d.py
larpix/configuration/configuration_v3.py
```

unless a real bug is demonstrated.

The mixed register test indicates these abstractions are already doing the right thing.

---

# 21. Known-good bench tools Codex should be able to read

The following local scratch tools contain useful ground truth and should be copied into the CERN repository or otherwise made visible in the Codex workspace:

```text
~/cern-coldbox/scratch/pacman-tests/power_off_rev5.py
~/cern-coldbox/scratch/pacman-tests/power_tile_rev5.py
~/cern-coldbox/scratch/pacman-tests/scan_rev5_power_ports.py
~/cern-coldbox/scratch/pacman-tests/sniff_pacman_raw.py
~/cern-coldbox/scratch/pacman-tests/bootstrap_v3_root_hijinks.py
~/cern-coldbox/scratch/pacman-tests/mixed_asic_register_test.py
```

The probe files may also be useful historically, but note the accidental filename:

```text
probe_larpix_hijinks.py.
```

with a trailing period.

Do not let Codex mistake the older unmapped probe for the known-good bootstrap.

Recommended action: copy the useful mapped probe into the handoff area under a clear new filename while preserving the original if desired.

---

# 22. Known-good generated network/config artifacts

The v2d Hydra run generated:

```text
iog_1-tile_7-hydra-network.json
```

in the FSD worktree/current run directory.

This file is valuable as:

```text
- a real CERN v2d Hydra topology example;
- proof of the reachable chip population;
- a test input for network enforcement;
- a reference for config_loader/network_larpix changes.
```

Copy it into the CERN working tree before Codex starts.

For v3, preserve any generated network JSON once the v3 tile discovery is run. The root-level communication is already proven even if the full tile JSON is not yet present.

---

# 23. Recommended CERN repository handoff layout

Before handing the workspace to Codex, create something like:

```text
crs-cern/
|
|-- docs/
|   `-- cern-coldbox/
|       |-- 01_context.md
|       |-- 02_goals_implementation.md
|       |-- 03_rev5_hijinks_bench_addendum.md
|       `-- 04_context3_codex_handoff_2026-09-09.md
|
|-- scratch/
|   `-- cern-bench-validation/
|       |-- README.md
|       |-- power_off_rev5.py
|       |-- power_tile_rev5.py
|       |-- scan_rev5_power_ports.py
|       |-- sniff_pacman_raw.py
|       |-- bootstrap_v3_root_hijinks.py
|       `-- mixed_asic_register_test.py
|
|-- configs/
|   `-- bench/
|       |-- pacman66_v3.json
|       |-- pacman67_v2d.json
|       `-- iog_1-tile_7-hydra-network.json
|
|-- normal CRS_DAQ source...
```

The exact directory naming is not important. The important point is that Codex has local, version-controlled access to the evidence and known-good test programs.

If the datasheets are acceptable to keep in the repository/workspace, make them available too:

```text
LArPix-v2d Datasheet
LArPix-v3 Datasheet
```

If repository size/policy makes committing PDFs undesirable, keep them in the workspace and put their paths in `docs/cern-coldbox/README.md`.

---

# 24. Local Git checkpoint before Codex

Do **not** hand Codex a working tree containing unrecorded bench fixes without first making a checkpoint.

At minimum, collect:

```text
current branch
current commit
git status --short
git diff
git diff --cached
```

for:

```text
~/cern-coldbox/worktrees/crs-cern
~/cern-coldbox/src/larpix-control
```

Also inspect the donor worktrees:

```text
~/cern-coldbox/worktrees/crs-fsd-run-delay
~/cern-coldbox/worktrees/crs-v3_10x16
```

so local donor edits used during the bench tests are not lost.

Recommended pattern:

```bash
cd ~/cern-coldbox/worktrees/crs-cern

git status --short
git diff
git rev-parse HEAD
git branch --show-current

# Copy the context, bench tools, known configs/network JSONs into
# version-controlled handoff directories.

git add \
    docs/cern-coldbox \
    scratch/cern-bench-validation \
    configs/bench

# Also stage any already-existing CERN implementation changes
# that are known to be part of the successful baseline.

git status
git diff --cached

git commit -m "CERN coldbox: checkpoint bench validation and Codex handoff"
```

For `larpix-control`:

```bash
cd ~/cern-coldbox/src/larpix-control

git status --short
git diff
git rev-parse HEAD
git branch --show-current

# If there are local modifications that were used by the successful
# bench tests, commit them on the current CERN/local development branch
# before Codex changes anything.
```

Do not blindly `git add -A` before reviewing generated data files, HDF5 files, large plots, credentials, or unrelated work.

A local checkpoint commit is useful even if it is not pushed immediately.

---

# 25. Codex implementation contract

Codex should be given this explicit task statement:

> Modify one CERN `crs_daq` source tree so that the existing 2x2-style high-level workflow can operate homogeneous Rev5/Hijinks PACMANs hosting either LArPix-v2d or LArPix-v3. Use `RUN_CONFIG.json` as the family source of truth. Preserve one control process per PACMAN/IOG. Use `larpix-control` semantic `Configuration_v2d` / `Configuration_v3` properties rather than hardcoded ASIC register addresses. Port the known-good Rev5/Hijinks logical→physical UART behavior. Reuse the proven FSD v2d and v3_10x16 networking algorithms behind family dispatch. Make `network_larpix.py`, `configure_larpix.py`, `run/iog/network.sh`, and `run/iog/configure.sh` operate correctly for both families. Keep `record_data.py` raw/ASIC-agnostic for mixed acquisition and verify both IOGs are preserved. Avoid an invasive `larpix-control` rewrite unless a bench-proven requirement demands it.

Codex should begin by:

```text
1. reading all four context documents;
2. reading the known-good scratch scripts;
3. inspecting the current local larpix-control code actually imported by Python;
4. inspecting current crs-cern changes;
5. comparing relevant files with fsd-run-delay and v3_10x16;
6. producing a short implementation plan;
7. modifying the code;
8. running software-only tests/static checks;
9. leaving explicit bench test commands for the operator.
```

---

# 26. Acceptance tests after Codex changes

## Test A — Preserve the mixed ASIC semantic-register proof

The existing:

```text
mixed_asic_register_test.py
```

should still pass.

Expected core behavior:

```text
v2d:
    Configuration_v2d
    reg 128 -> 0x60
    digital_monitor_chan -> register 119
    0 -> 1 -> 0

v3:
    Configuration_v3
    reg 128 -> 0x60
    digital_monitor_chan -> register 115
    0 -> 1 -> 0
```

This is the best small hardware regression test that ASIC register-space translation still works.

## Test B — v2d Hydra discovery from the CERN tree

From the CERN source tree only:

```text
PACMAN #67
IOG 1
tile 7
```

Expected:

```text
roots 21 / 61 / 101 usable
logical 28 external root unavailable
network discovery succeeds/reroutes
```

No FSD worktree should be required at runtime.

## Test C — v3 root/Hydra from the CERN tree

At minimum reproduce:

```text
PACMAN #66
IOG 2
tile 10
logical 37 -> physical 30
chip 1 register 122 reply
```

Then run the v3 Hydra discovery path when ready.

## Test D — `network_larpix.py` per IOG

Run from the same source tree:

```text
IOG 1 -> v2d packet family 2
IOG 2 -> v3 packet family 3
```

Both should enforce saved networks/configs without wrong-family packet errors.

## Test E — concurrent `run/iog/network.sh`

Launch both IOGs concurrently.

Failures/retries must remain isolated per process.

## Test F — `configure_larpix.py`

Load and enforce ASIC configuration files for each family.

Verify that config files retain:

```text
meta.ASIC_VERSION = "2d"
```

or:

```text
meta.ASIC_VERSION = 3
```

and that the correct Configuration class is created when loading.

## Test G — `run/iog/configure.sh`

Launch both configuration jobs concurrently from the same source tree.

## Test H — mixed raw acquisition

Run one raw recorder with aggregate PACMAN config:

```text
IOG 1 -> .103
IOG 2 -> .102
```

Acquire 10–30 seconds.

Verify raw HDF5 contains both IOGs.

Do not use packet-mode HDF5 for this test.

## Test I — offline family-aware decode

For each raw PACMAN message:

```text
IOG 1 -> parse ASIC payload as v2 / Packet_v2
IOG 2 -> parse ASIC payload as v3 / Packet_v3
```

Verify sensible chip IDs, channels, timestamps, packet declarations, ADC fields, and parity.

---

# 27. Things Codex should not do

Do not:

```text
- create separate permanent crs_daq installations for v2d and v3;
- replace logical Chip-Key channels with physical Hijinks UART numbers;
- assume an immediate CONFIG_READ after hard reset proves root health;
- enable all physical UART RXs as a normal configuration;
- hardcode v2d/v3 ASIC register numbers throughout CRS_DAQ;
- assume register 127 has the same semantic meaning in both families;
- use v3 parsed HDF5 for a mixed-family run;
- hardcode PACMAN_IO(asic_version=3) in shared control code;
- silently use a donor branch's io/pacman.json;
- call add_chip() without checking the required ASIC version;
- rewrite Packet_v2 / Packet_v3 merely because DATA packets differ;
- infer final six-PACMAN hardware mapping from approximate tile counts;
- remove family-specific Hydra physical-layer settings in the name of cleanup.
```

---

# 28. Current milestone status

```text
[✓] Freeze initial software baselines

[✓] Verify v2d/v3 CONFIG packet compatibility

[✓] Verify PACMAN command-server connectivity

[✓] Verify Rev5 register read/write

[✓] Verify Rev5 tile power control/readback

[✓] Understand Hijinks logical 40 -> physical 32 UART mapping

[✓] Locate v3 tile:
        PACMAN #66 / IOG 2 / tile 10

[✓] Locate v2d tile:
        PACMAN #67 / IOG 1 / tile 7

[✓] Bootstrap/read v3 root:
        logical 37 / physical 30 / chip 1

[✓] Run v2d Hydra root setup:
        25 -> root 21
        26 -> root 61
        27 -> root 101
        28 -> dead external link

[✓] Complete v2d Hydra discovery with 0 non-configured chips

[✓] Observe real raw v2d DATA replies through Hijinks

[✓] Prove one larpix-control installation supports both register maps

[✓] Controlled v2d ASIC write/read/restore

[✓] Controlled v3 ASIC write/read/restore

[ ] Move both Hydra discovery paths into one CERN crs_daq tree

[ ] Finalize CERN RUN_CONFIG.json

[ ] Fix Rev5/Hijinks PACMAN helpers throughout CERN crs_daq

[ ] Fix network_larpix.py family dispatch/enforcement

[ ] Fix run/iog/network.sh for CERN mapping

[ ] Fix configure_larpix.py family-specific PACMAN_IO construction

[ ] Fix run/iog/configure.sh for CERN mapping

[ ] Audit all shared utilities for old Packet/register/test-mode assumptions

[ ] Verify mixed raw record_data.py output

[ ] Prove offline mixed-family decode

[ ] Scale from the two-PACMAN bench to the full CERN system
```

---

# 29. Core implementation principle

The bench work has reduced the problem substantially.

The right implementation principle is:

> **Use one shared CRS_DAQ source tree and one shared `larpix-control` implementation. Keep each PACMAN control process homogeneous and select its packet family from configuration. Let `Configuration_v2d` and `Configuration_v3` translate semantic ASIC settings into their family-specific physical register spaces. Put Rev5/Hijinks logical-to-physical UART translation in the PACMAN hardware layer. Keep mixed high-rate acquisition raw and decode by IOG later.**

Or, more compactly:

```text
CRS_DAQ should know:
    which PACMAN / IOG is v2d or v3
    how to launch the proper Hydra path
    how Rev5/Hijinks maps logical channels to physical UARTs

larpix-control should know:
    which ASIC register corresponds to a semantic setting
    how to build the family-correct configuration packet
    how to parse the family-correct packet

record_data should know:
    which PACMAN dataservers to listen to
    how to preserve raw messages + io_group

offline decoding should know:
    io_group -> ASIC family
```

That boundary is now supported by real bench measurements.

---

# 30. Final handoff statement

As of September 9, 2026, the central mixed-family control risk has been retired at the primitive level.

We have demonstrated on real CERN bench hardware that:

```text
PACMAN #67 / LArPix-v2d
and
PACMAN #66 / LArPix-v3
```

can both be controlled by the same local software stack, including:

```text
- Rev5 PACMAN access;
- Hijinks logical/physical UART handling;
- family-correct packet creation and parsing;
- family-correct ASIC configuration-register maps;
- real ASIC CONFIG_READ;
- real ASIC CONFIG_WRITE;
- readback verification;
- restoration of the original ASIC state.
```

The remaining work is primarily a **CRS_DAQ integration and assumption-audit task**, not a proof-of-principle R&D task.

Codex should now make the existing high-level 2x2 workflow consistently use the already-proven Rev5/Hijinks and v2d/v3 abstractions across the full codebase.
