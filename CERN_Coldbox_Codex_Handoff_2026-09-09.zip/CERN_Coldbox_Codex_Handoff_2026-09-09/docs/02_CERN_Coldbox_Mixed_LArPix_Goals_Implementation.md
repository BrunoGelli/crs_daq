# CERN Coldbox Mixed LArPix v2d / v3a — Goals and Implementation Steps

**Goal:** Obtain a working mixed-family CERN coldbox control and raw-acquisition chain as quickly as possible while keeping the changes small enough to understand and validate.

**Target platform:** PACMAN Rev5 + Hijinks  
**Control model:** one homogeneous control process per PACMAN  
**Acquisition model:** one raw recorder for all PACMANs  
**Preferred CRS base:** `2x2-run3-cooldown`  
**Rev5 donor/reference:** `v3_10x16`  
**v2d donor/reference:** FSD / `fsd-run-delay`  
**LArPix library:** `larpix-control/release`

---

# 1. Primary goals

## Goal A — Network both ASIC families from one operator workflow

The operator should issue one top-level networking command and have the software launch networking for all CERN PACMANs.

Internally:

- each PACMAN gets its own `network_larpix.py` process;
- a v2d PACMAN uses packet version 2;
- a v3a PACMAN uses packet version 3;
- all PACMAN hardware operations use Rev5/Hijinks register semantics.

Success means both families initialize, replies are readable, and retries remain local to the affected PACMAN/process.

## Goal B — Configure both ASIC families from one operator workflow

One top-level configuration command should launch all PACMAN configuration jobs.

Each job:

- loads the correct ASIC configuration files;
- uses the correct ASIC register class;
- transmits and reads configuration packets through the appropriate homogeneous `PACMAN_IO`;
- enforces the intended configuration.

Success means v2d and v3a readback both agree with their intended configurations and both can run concurrently.

## Goal C — Record all PACMANs into one raw file

One `record_data.py` process should connect to all CERN PACMAN data servers.

The raw path must use:

```python
c.io.disable_packet_parsing = True
c.io.enable_raw_file_writing = True
```

The acquisition process should not decode v2d/v3 payloads.

Success means the raw HDF5 contains messages from all expected `io_group`s and the `io_group -> ASIC family` mapping is archived with the run.

## Goal D — Prove offline decoding

A small validation script should read the raw output and select the decoder according to `io_group`:

```python
if io_group_asic_version_[iog] == "2d":
    parse(..., asic_version=2)
elif io_group_asic_version_[iog] == 3:
    parse(..., asic_version=3)
```

Success means both packet families decode into sensible fields from the same raw acquisition.

---

# 2. Implementation strategy

The fastest safe strategy is:

1. start from the 2x2 high-level workflow;
2. replace/port only PACMAN pieces that are wrong for Rev5;
3. borrow existing v2d and v3 networking implementations;
4. keep one PACMAN per control process;
5. leave raw acquisition undecoded;
6. test incrementally before scaling to the full detector.

Do **not** begin by redesigning `larpix-control` for a mixed parsed `PACMAN_IO`.

---

# 3. Step-by-step implementation

## Step 0 — Freeze the working baselines

Record the exact baselines:

```text
larpix-control/release
5a69050422e82356c8faf9ad0ea3168c322d63e8

crs_daq/2x2-run3-cooldown
3ccef841f1639f7199063530e485ddbbcd4b338c

crs_daq/v3_10x16
4a8b40f1abdcdbf3f66a75b7bb48f3259a3c12b9

crs_daq/fsd-run-delay
a020244ba774bd9be1bbbd850b423dc320a0d700
```

Create a CERN branch from `2x2-run3-cooldown`.

Suggested name:

```text
cern-coldbox-v2d-v3a-hijinks
```

## Step 1 — Define the CERN hardware mapping

Update `RUN_CONFIG.json` with the real ASIC-family map.

Example only:

```json
"io_group_asic_version_": {
    "1": "2d",
    "2": "2d",
    "3": 3,
    "4": 3,
    "5": 3,
    "6": 3
}
```

Also define:

- tiles belonging to each IOG;
- Rev5 PACMAN version for every IOG;
- correct power DAC settings;
- exclusions.

**Acceptance check:** print a summary such as:

```text
IOG 1 -> 2d -> packet version 2
IOG 2 -> 2d -> packet version 2
IOG 3 -> 3  -> packet version 3
...
```

## Step 2 — Create one PACMAN config file per PACMAN

Create:

```text
io/pacman_iog1.json
io/pacman_iog2.json
io/pacman_iog3.json
io/pacman_iog4.json
io/pacman_iog5.json
io/pacman_iog6.json
```

Each should contain exactly one PACMAN/IP pair.

Example:

```json
{
    "_config_type": "io",
    "io_class": "PACMAN_IO",
    "io_group": [
        [1, "192.168.xxx.xxx"]
    ]
}
```

Also retain one aggregate config for data taking:

```text
io/pacman.json
```

containing all six PACMANs.

## Step 3 — Add one common ASIC -> packet-version helper

Do not duplicate this logic across scripts.

Example:

```python
def get_packet_version(asic_version):
    if asic_version in ("2d", "2b", 2):
        return 2
    if asic_version == 3:
        return 3
    raise ValueError(
        f"Unsupported ASIC version for PACMAN packet format: {asic_version}"
    )
```

For CERN the important mappings are:

```text
"2d" -> 2
3    -> 3
```

## Step 4 — Port the Rev5/Hijinks PACMAN hardware layer

Treat `v3_10x16` / FSD as the reference for Rev5.

Port or reconcile:

```text
base/pacman_base.py
configure_pacman.py
```

Important Rev5 behavior includes:

- UART RX enable/disable using the Rev5 register model;
- logical IO-channel to physical UART mapping;
- packet-delay setup;
- Rev5 power/control registers;
- Rev5 reset/clock handling.

Do not preserve old Rev3/Rev4 register behavior merely because it exists in the 2x2 base.

**Acceptance check:** before touching a full LArPix network, connect to one Rev5 PACMAN, ping it, read/write a harmless PACMAN register, enable one intended UART, verify the expected register change, and disable it again.

## Step 5 — Bring in v2d and v3 networking implementations

Use as donors:

```text
base/network_base_FSD.py
base/network_base_FSD_v3.py
```

The CERN `network_larpix.py` should dispatch by ASIC family:

```python
asic_version = io_group_asic_version_[io_group]

if asic_version == "2d":
    c = network_base_FSD.network_v2b(...)
elif asic_version == 3:
    c = network_base_FSD_v3.network_v3(...)
else:
    raise RuntimeError(...)
```

The exact donor function names can be cleaned up later; correctness matters more than naming today.

Every invocation receives a one-PACMAN `pacman_config`, then creates its enforcement I/O as:

```python
packet_version = get_packet_version(asic_version)

nc.io = larpix.io.PACMAN_IO(
    relaxed=True,
    config_filepath=pacman_config,
    asic_version=packet_version
)
```

Do not retain a globally hardcoded `asic_version=3` from the donor branch.

**Acceptance check:** network one v2d PACMAN and one v3 PACMAN independently, then simultaneously.

## Step 6 — Update `configure_larpix.py`

Remove globally hardcoded packet versions from the control path.

For a one-PACMAN config:

```python
io_group = pacman_configs["io_group"][0][0]
asic_version = io_group_asic_version_[io_group]
packet_version = get_packet_version(asic_version)
```

then:

```python
c.io = larpix.io.PACMAN_IO(
    relaxed=True,
    config_filepath=pacman_config,
    asic_version=packet_version
)
```

The chip configuration itself remains driven by the ASIC metadata in saved configuration files.

**Acceptance check:** on one root chip from each family, write one safe configuration value, read it back, restore it, and read it back again.

## Step 7 — Adapt the top-level networking script

Use the existing 2x2 parallel-process pattern.

A CERN `run/network.sh` should launch one job per PACMAN, conceptually:

```bash
python network_larpix.py --pacman_config io/pacman_iog1.json ... &
python network_larpix.py --pacman_config io/pacman_iog2.json ... &
...
wait
```

Prefer clear per-IOG log names.

Desired behavior:

```text
./run/network.sh all
```

networks all PACMANs, while a single IOG remains runnable for debugging.

## Step 8 — Adapt the top-level configuration script

Do the same for `run/configure.sh`.

Desired behavior:

```text
./run/configure.sh all
```

configures the full CERN charge-readout system, with individual PACMAN operation still possible.

## Step 9 — Keep `record_data.py` raw

Use aggregate `io/pacman.json` containing all PACMANs.

For the first implementation it is acceptable to retain:

```python
c.io = larpix.io.PACMAN_IO(
    relaxed=True,
    config_filepath=pacman_config,
    asic_version=3
)
```

solely because the current constructor requires a version.

The actual mixed acquisition path must remain:

```python
c.io.disable_packet_parsing = True
c.io.enable_raw_file_writing = True
```

Do **not** use `--packet` for the mixed run.

**Acceptance check:** run 10–30 seconds with two PACMANs first and verify both `io_group`s are present in the raw HDF5.

## Step 10 — Archive the ASIC-family mapping with every run

Archive at minimum:

- `RUN_CONFIG.json`;
- aggregate `io/pacman.json`;
- current CRS commit SHA;
- current `larpix-control` commit SHA;
- PACMAN/Hijinks firmware identifier if available.

This prevents future decoding from depending on mutable local configuration.

## Step 11 — Write a small mixed raw-decoder validation script

The first script only needs to prove the architecture.

Pseudo-code:

```python
mapping = {
    1: 2,
    2: 2,
    3: 3,
    4: 3,
    5: 3,
    6: 3,
}

for io_group, msg in raw_messages:
    packets = pacman_msg_format.parse(
        msg,
        io_group=io_group,
        asic_version=mapping[io_group]
    )
```

Print/tally:

- packet count per IOG;
- data/config/sync/trigger counts;
- valid parity fraction;
- chip IDs;
- channel IDs;
- ADC min/max;
- timestamp ranges.

For v3, verify 10-bit ADC interpretation explicitly.

---

# 4. Fast validation ladder for today

Do not start with all sixty tiles.

## Test 1 — Software-only configuration packet equality

Construct the same chip ID, register address, and register data as both `Packet_v2` and `Packet_v3`, set the magic word and parity, and assert:

```python
packet_v2.bytes() == packet_v3.bytes()
```

This is a quick implementation-level proof of the common configuration wire format.

## Test 2 — Two PACMANs, one root chip each

Use one v2d PACMAN and one v3a PACMAN.

For each:

1. initialize Rev5 PACMAN state;
2. enable the correct UART;
3. contact the root chip;
4. issue one configuration read;
5. issue one safe write;
6. verify by readback.

Then run both in parallel.

## Test 3 — One tile per family

Network one v2d tile and one v3a tile.

Check expected chip count, chip IDs, no runaway packet storm, and successful readback/enforcement.

## Test 4 — Configure both tiles simultaneously

Launch both `configure_larpix.py` processes together.

Confirm both complete, logs remain clear, and no wrong-family packet errors occur.

## Test 5 — Mixed raw acquisition

Connect one `record_data.py` to both PACMANs and acquire 10–30 seconds.

Verify both IOGs are present in the raw HDF5.

## Test 6 — Offline mixed decode

Decode by IOG.

For v2d verify packet declaration, 8-bit ADC, chip/channel values, timestamp, and parity.

For v3a verify v3 packet declaration, 10-bit ADC, CDS/reset flags where applicable, chip/channel values, timestamp, and parity.

## Test 7 — Scale PACMAN count

Add PACMANs incrementally:

```text
2 -> 3 -> 4 -> 5 -> 6
```

## Test 8 — Scale tile count

Once all PACMAN control paths are proven, expand to the full tile population.

At this stage remaining problems are more likely to be physical Hydra connectivity, individual ASIC failures, configuration quality, or data rate rather than mixed-family architecture.

---

# 5. Files likely to change

The first implementation will likely touch:

```text
RUN_CONFIG.json

io/pacman.json
io/pacman_iog1.json
...
io/pacman_iog6.json

base/pacman_base.py
base/network_base_FSD.py
base/network_base_FSD_v3.py
base/utility_base.py          # only if needed for common helper(s)

configure_pacman.py
network_larpix.py
configure_larpix.py
record_data.py                # minimal/no mixed-specific change expected

run/network.sh
run/configure.sh
```

Potentially also controller/network configuration JSON files depending on CERN layout organization.

---

# 6. Files that should ideally not need invasive changes

Avoid unnecessary modification of:

```text
larpix-control/larpix/packet/packet_v2.py
larpix-control/larpix/packet/packet_v3.py
larpix-control/larpix/format/pacman_msg_format.py
larpix-control/larpix/io/pacman_io.py
```

The current library is sufficient for the first CERN architecture if each control process remains homogeneous.

If a later requirement demands one parsed `PACMAN_IO` spanning multiple ASIC families, that should become a separate `larpix-control` feature.

---

# 7. Known pitfalls to watch

## Pitfall 1 — Hardcoded `asic_version=3`

Search the CERN branch for:

```text
asic_version=3
```

Every control-path occurrence must be reviewed. Raw `record_data.py` is the intentional temporary exception.

## Pitfall 2 — Old Rev3/Rev4 PACMAN registers

Do not accidentally retain 2x2-specific UART enable and PACMAN control registers where Rev5 differs.

## Pitfall 3 — Mixed PACMAN configs in control processes

If one `network_larpix.py` or `configure_larpix.py` invocation receives both v2d and v3 IOGs, the homogeneous assumption breaks.

For the first implementation:

> **one PACMAN per control-process config.**

## Pitfall 4 — Parsed mixed acquisition

Do not enable packet parsing in the high-rate mixed recorder.

Raw first.

## Pitfall 5 — v3 dynamic/status registers

If full v3 configuration enforcement repeatedly reports differences in statistics registers, do not immediately interpret that as broken communication; some registers can be updated by the ASIC.

## Pitfall 6 — v2d/v3 packet-version terminology

Remember:

```text
ASIC "2d" != PACMAN packet version "2d"
```

For PACMAN message formatting:

```text
v2d -> 2
v3a -> 3
```

---

# 8. Minimal helper API recommended

A tiny common function is enough:

```python
def asic_to_packet_version(asic_version):
    if asic_version == "2d":
        return 2
    if asic_version == 3:
        return 3
    raise ValueError(f"Unsupported CERN ASIC version: {asic_version}")
```

Optional guard:

```python
def single_iog_from_pacman_config(pacman_configs):
    groups = [entry[0] for entry in pacman_configs["io_group"]]
    if len(groups) != 1:
        raise RuntimeError(
            "CERN control commands require exactly one PACMAN/io_group per process"
        )
    return groups[0]
```

This makes the architecture explicit instead of relying only on convention.

---

# 9. Definition of done for the first CERN milestone

- [ ] all PACMANs use Rev5/Hijinks register logic;
- [ ] every PACMAN has a defined ASIC family;
- [ ] every control process owns exactly one PACMAN;
- [ ] v2d networking succeeds;
- [ ] v3a networking succeeds;
- [ ] both can network concurrently;
- [ ] v2d configuration/readback succeeds;
- [ ] v3a configuration/readback succeeds;
- [ ] both can configure concurrently;
- [ ] one raw recorder connects to all PACMANs;
- [ ] raw output contains messages from every expected IOG;
- [ ] offline decoding by IOG works for both packet families;
- [ ] the IOG/family mapping is archived with the run.

---

# 10. Stretch goals after first success

Only after the first system works:

1. remove the dummy `asic_version` requirement for explicitly raw-only `PACMAN_IO`;
2. add a polished mixed raw-file decoder;
3. add automated data-quality checks per IOG/family;
4. consider a formal mixed parsed-HDF5 representation if useful;
5. consider native multi-family `PACMAN_IO` support;
6. add Zipline support if CERN migrates firmware/message format;
7. integrate the final workflow with higher-level CRS run control / DUNE DAQ.

---

# 11. Recommended order of work today

```text
1. Rev5 PACMAN register layer
2. one-PACMAN packet-version selection
3. v2d networking
4. v3 networking
5. one root each
6. one tile each
7. configure both
8. raw record both
9. offline decode both
10. scale to six PACMANs
```

Do not spend the first hours redesigning the raw format or `larpix-control`.

---

# 12. Core implementation principle

> **Use the existing hardware partition to keep each control process simple. Orchestrate different ASIC families at the CRS level, not inside the ASIC packet parser. Record raw PACMAN messages from everything and decode by source later.**

This is the shortest path from the existing 2x2/FSD/v3 software to a working CERN mixed v2d/v3a system.
