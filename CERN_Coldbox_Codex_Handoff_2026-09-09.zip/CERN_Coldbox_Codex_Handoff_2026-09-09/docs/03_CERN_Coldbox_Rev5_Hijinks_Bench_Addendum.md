# CERN Coldbox Mixed LArPix v2d / v3a Software Context  
## Addendum — Rev5 Hijinks Bench Validation and First Successful v3 Root Communication

**Date:** September 8, 2026  
**Status:** First end-to-end LArPix-v3 root-chip communication successfully demonstrated on the CERN bench PACMAN setup.

---

# 1. Major result

We have now demonstrated a complete communication path from the CERN DAQ machine through a Rev5 PACMAN running Hijinks firmware to a real LArPix-v3 root ASIC.

The successful chain was:

```text
dune01
  ↓
larpix-control / PACMAN_IO(asic_version=3)
  ↓
PACMAN #66
  IP 192.168.0.102
  firmware 2.8
  ↓
Hijinks logical-channel mapping
  ↓
logical IO channel 37
  ↓
physical UART 30
  ↓
LArPix-v3 root ASIC, chip ID 1
  ↓
CONFIG_READ reply
  ↓
chip_id register 122 = 1
  valid parity
```

The exact successful response was:

```text
[ Key: 2-37-1 |
  Chip: 1 |
  Downstream |
  Read |
  Register: 122 |
  Value: 1 |
  Receipt TS: 2316686 |
  Parity: 0 (valid: True) ]
```

The final diagnostic reported:

```text
received Packet_v3: 1
valid parity:       1
exact matches:      1

PASS: ROOT CHIP COMMUNICATION WORKS
```

This is the first strong hardware-level validation of the CERN mixed-family software architecture.

---

# 2. Current CERN bench hardware mapping

The two PACMANs currently used are:

```text
PACMAN #66
IP:        192.168.0.102
io_group:  2
ASIC:      LArPix v3
PACMAN_IO: asic_version=3
```

```text
PACMAN #67
IP:        192.168.0.103
io_group:  1
ASIC:      LArPix v2d
PACMAN_IO: asic_version=2
```

The v3 tile connected to PACMAN #66 was experimentally located at:

```text
PACMAN power connection / tile slot 10
```

This was determined by sequentially powering each PACMAN tile output and measuring Rev5 power readback.

Tiles 1–9 showed essentially zero load:

```text
IDDA ≈ 0–1 mA
IDDD ≈ 0–1 mA
```

Tile 10 showed:

```text
VDDA ≈ 2148–2149 mV
IDDA ≈ 816–817 mA

VDDD ≈ 1227–1228 mV
IDDD ≈ 497–499 mA
```

Therefore the previous tests on tile slot 1 were probing an unloaded output rather than the real v3 tile.

The working CERN bench DAC values were:

```text
VDDD_DAC = 28000
VDDA_DAC = 52000
```

These currently produce approximately:

```text
VDDA ≈ 2.15 V
VDDD ≈ 1.23 V
```

on the connected tile.

The v2d tile location on PACMAN #67 has not yet been established with the same power-port scan and should be determined separately.

---

# 3. Hijinks architecture clarified

A private firmware note describing the first Hijinks bundle resolved the apparent conflict between:

- 10 physical tiles × 4 links = 40 logical LArPix channels
- only 32 physical PACMAN UART engines

Hijinks intentionally presents a **40-channel logical DAQ interface** while internally mapping those logical channels onto 32 physical UARTs.

Eight logical channels are intentionally non-functional.

The logical-to-physical mapping is:

```text
 logical   physical
 ------------------
  1  ->  1
  2  ->  2
  3  ->  3
  4  ->  4

  5  ->  5
  6  ->  6
  7  ->  7
  8  ->  8

  9  ->  9
 10  -> 10
 11  -> 11
 12  -> dead

 13  -> 12
 14  -> 13
 15  -> 14
 16  -> dead

 17  -> 15
 18  -> 16
 19  -> 17
 20  -> dead

 21  -> 18
 22  -> 19
 23  -> 20
 24  -> dead

 25  -> 21
 26  -> 22
 27  -> 23
 28  -> dead

 29  -> 24
 30  -> 25
 31  -> 26
 32  -> dead

 33  -> 27
 34  -> 28
 35  -> 29
 36  -> dead

 37  -> 30
 38  -> 31
 39  -> 32
 40  -> dead
```

Thus the intentionally dead logical channels are:

```text
12, 16, 20, 24, 28, 32, 36, 40
```

This same mapping already exists in the FSD `fsd-run-delay` branch inside:

```python
convert_io_channel_to_uart()
```

in `base/pacman_base.py`. 

Therefore the strange 40→32 translation seen in FSD is not merely an obsolete software workaround: it represents the Hijinks firmware architecture.

---

# 4. Important distinction: logical channel vs physical UART

This distinction must be preserved throughout the CERN software.

## Logical IO channel

The DAQ, LArPix controller, chip key, data stream, and PACMAN network protocol use the **logical channel**.

Example:

```text
Key(2, 37, 1)
```

means:

```text
io_group   = 2
io_channel = 37
chip_id    = 1
```

The command sent to pacman-server is addressed to logical channel 37.

Hijinks/pacman-server then internally maps that TX traffic to physical UART 30.

## Physical UART

Certain low-level PACMAN FPGA registers still refer to the **32 physical UART engines**.

For example:

```text
logical channel 37 -> physical UART 30
```

Therefore:

```text
LArPix packet TX channel = 37
PACMAN RX-enable bit     = UART 30
PACMAN UART clock reg    = UART 30
PACMAN packet-delay reg  = UART 30
```

The logical channel must NOT be replaced with 30 in the LArPix chip key.

Correct:

```text
Key(2, 37, 1)
```

Incorrect:

```text
Key(2, 30, 1)
```

---

# 5. Current PACMAN firmware

PACMAN #66 firmware registers were read directly through PACMAN_IO:

```text
Firmware Major       0x0000 -> 2
Firmware Minor       0x0004 -> 8
Build                0x0008 -> 2
Debug                0x000c -> 5

Tile Enable          0x0010 -> 0x00000200
Analog Power Enable  0x0014 -> 0x00000001
Sync Mask            0x0018 -> 0x000003ff
Legacy Tile Enable   0x001c -> 0x000003ff
```

Therefore the currently running firmware is:

```text
PACMAN firmware 2.8
build 2
debug code 0x00000005
```

The private documentation describing Hijinks 2.2 is therefore historical, not the exact firmware version currently installed.

However, its architecture agrees closely with the existing FSD software mapping and with the behavior observed experimentally.

The 10-bit registers also work as expected:

```text
tile_enable = 0x200
```

corresponds to PACMAN tile 10.

The sync mask:

```text
0x3ff
```

covers all ten tile positions.

---

# 6. FSD branch now understood as a very important donor

The `fsd-run-delay` branch explicitly configures ten tiles per Rev5 PACMAN:

```json
"1": [1,2,3,4,5,6,7,8,9,10]
```

and similarly for its other PACMANs. 

Its Rev5 configuration path uses:

```text
Tile Enable: 0x0010
Global/analog power: 0x0014
Sync Mask: 0x0018

VDDD DAC: 0x24020 + tile-1
VDDA DAC: 0x24010 + tile-1

VDDA ADC: 0x24030 + tile-1
VDDD ADC: 0x24040 + tile-1
IDDA ADC: 0x24050 + tile-1
IDDD ADC: 0x24060 + tile-1
```

which are the same registers successfully validated on the CERN PACMANs. 

Its `pacman_base.py` also contains exactly the Hijinks logical→physical UART mapping described above. 

This makes the FSD branch one of the strongest donors for Rev5/Hijinks behavior.

---

# 7. PACMAN RX-enable semantics confirmed experimentally

Register:

```text
0x201c
```

is an active-low 32-bit **physical UART RX enable mask**.

Semantics:

```text
1 = disabled
0 = enabled
```

Experimentally:

```text
0xffffffff
```

silences all RX traffic.

Enabling an unconnected physical UART produces a large amount of garbage traffic.

For physical UART N:

```python
mask = 0xffffffff & ~(1 << (N - 1))
```

For the successful logical channel 37 / physical UART 30 test:

```text
RX mask = 0xdfffffff
```

This enabled only physical UART 30.

Expected masks for tile-10 working channels are:

```text
logical 37 -> UART 30 -> 0xdfffffff
logical 38 -> UART 31 -> 0xbfffffff
logical 39 -> UART 32 -> 0x7fffffff
logical 40 -> dead
```

This RX mask should remain a **physical-UART operation**, not a logical-channel operation.

---

# 8. Why the earlier packet floods were misleading

When all RX channels were enabled:

```text
0x201c = 0x00000000
```

the PACMAN produced thousands of frames resembling random or nearly all-ones UART words.

Examples decoded into apparent packets such as:

```text
chip 255
chip 247
chip 239
chip 127
...
```

with random combinations of:

```text
CONFIG_READ
CONFIG_WRITE
DATA
upstream/downstream
```

Some had valid parity.

These should NOT be interpreted as genuine LArPix packets.

A one-bit parity check passes random data approximately 50% of the time, so a packet with valid parity is not sufficient evidence by itself.

A genuine configuration response should match the full expected signature:

```text
correct io_group
correct logical io_channel
correct chip ID
CONFIG_READ packet type
correct register address
valid parity
expected register value
```

The successful packet satisfied all of these simultaneously.

---

# 9. The original root-read test was conceptually incomplete

An important discovery is that a freshly hard-reset LArPix-v3 root should not necessarily be expected to immediately drive a usable configuration-read response.

The v3 networking donor first **writes communication settings into the root ASIC**, then enables the PACMAN receiver, and only afterward performs reconciliation/readback. 

The relevant v3 root settings are:

```text
i_rx0..3        = 3
r_term0..3      = 7
v_cm_lvds_tx0..3 = 5

enable_posi = [0, 0, 0, 1]

i_tx_diff2 = 7
tx_slices2 = 15

enable_piso_downstream = [0, 0, 1, 0]
enable_piso_upstream   = [0, 0, 0, 0]
```

Most importantly:

```text
enable_piso_downstream[2] = 1
```

establishes the root's return communication path toward PACMAN.

Therefore the appropriate primitive is not:

```text
hard reset
→ CONFIG_READ
```

but rather:

```text
hard reset
→ bootstrap root communication registers using CONFIG_WRITE
→ enable mapped PACMAN RX UART
→ CONFIG_READ
```

The writes can be sent before PACMAN RX is enabled because MOSI/TX and MISO/RX are distinct communication directions.

---

# 10. v3 physical-UART clock configuration

The v3 `v3_10x16/configure_pacman.py` donor explicitly converts each logical IO channel to its physical Hijinks UART and then executes:

```python
c.io.set_uart_clock_ratio(uart, 1)
```

for valid physical UARTs. 

For logical channel 37:

```text
logical 37
→ physical UART 30
```

the successful test therefore used:

```text
UART 30 clock ratio = 1
```

The packet-delay register also refers to the physical UART.

For physical UART 30:

```text
packet delay register = 0x20014
```

Successful setup:

```text
old: 0x00000101
new: 0x0000ff01
```

Thus for v3/Hijinks the working sequence includes:

```text
physical UART clock ratio = 1
packet delay = 0xff
```

before ASIC communication.

---

# 11. Exact successful v3 bootstrap sequence

The successful diagnostic was:

```text
bootstrap_v3_root_hijinks.py
```

run as:

```bash
python3 ~/cern-coldbox/scratch/pacman-tests/bootstrap_v3_root_hijinks.py \
    --config ~/cern-coldbox/configs/pacman66_v3.json \
    --io-group 2 \
    --io-channel 37
```

The sequence was:

```text
1. Confirm PACMAN/tile already powered.

2. Disable all PACMAN RX:
       0x201c = 0xffffffff

3. Map:
       logical 37 -> physical UART 30

4. Set physical UART 30 clock ratio:
       ratio = 1

5. Set physical UART 30 packet delay:
       0x20014 -> 0x0000ff01

6. Hard-reset LArPix:
       reset length = 4096 cycles

7. Create root:
       Key(2, 37, 1)
       version = 3

8. Write v3 root communication settings:
       i_rx[0:3] = 3
       r_term[0:3] = 7
       v_cm_lvds_tx[0:3] = 5

       enable_posi = [0,0,0,1]

       i_tx_diff2 = 7
       tx_slices2 = 15

       enable_piso_downstream = [0,0,1,0]
       enable_piso_upstream   = [0,0,0,0]

9. Enable only physical RX UART 30:
       0x201c = 0xdfffffff

10. Request:
       chip ID 1
       CONFIG_READ
       register 122 ("chip_id")

11. Receive exactly one valid reply:
       logical io_channel = 37
       chip ID = 1
       register = 122
       value = 1
       parity valid
```

Result:

```text
PASS: ROOT CHIP COMMUNICATION WORKS
```

---

# 12. Important scripting accident discovered

There were temporarily two files:

```text
probe_larpix_hijinks.py
probe_larpix_hijinks.py.
```

because this command was accidentally used:

```bash
nano ~/cern-coldbox/scratch/pacman-tests/probe_larpix_hijinks.py.
```

with a trailing period.

The newer mapped-Hijinks implementation was therefore saved to:

```text
probe_larpix_hijinks.py.
```

while subsequent commands continued running:

```text
probe_larpix_hijinks.py
```

This explained why the expected physical-UART setup did not initially appear in the program output.

This should be cleaned up later to avoid confusion.

---

# 13. SSH issue

Both PACMANs expose an old Dropbear SSH server:

```text
dropbear_2017.75
```

The modern SSH/OpenSSL environment on `dune01` reaches the server and completes the initial key exchange, but fails while verifying the legacy RSA/SHA-1 host signature:

```text
openssl ...
do_sigver_init: invalid digest

ssh_dispatch_run_fatal:
error in libcrypto
```

This is not a network connectivity problem.

For current development, SSH is not required because:

```text
PACMAN command server 5555 works
PACMAN data server    5556 works
PACMAN registers can be read/written remotely
```

If PACMAN-shell access is later required, using an older compatible SSH client/container is preferable to weakening the crypto policy of the DAQ machine.

---

# 14. What has now been proven

The following are experimentally demonstrated on the CERN bench:

```text
✓ dune01 can communicate with both PACMAN command servers.

✓ Rev5 PACMAN register read/write works through PACMAN_IO.

✓ Rev5 10-tile power registers work.

✓ Tile 10 can be powered through the 10-bit tile-enable register.

✓ Rev5 voltage/current ADC readback works.

✓ The real v3 tile is connected to PACMAN #66 tile 10.

✓ Hijinks uses logical 40-channel addressing with physical 32-UART
  receive/control underneath.

✓ Logical channel 37 corresponds to physical UART 30.

✓ PACMAN TX can send a v3 configuration packet on logical channel 37.

✓ A pristine v3 root can be bootstrapped through configuration writes.

✓ Its return PISO path can be enabled.

✓ PACMAN physical UART 30 can receive its reply.

✓ PACMAN dataserver returns the reply tagged as logical IO channel 37.

✓ larpix-control Packet_v3 parses the returned frame correctly.

✓ chip 1 register 122 can be read back as value 1 with valid parity.
```

This establishes:

```text
PACMAN #66 Rev5/Hijinks
       ↓
io_group 2
       ↓
logical IO channel 37
       ↓
Hijinks mapping
       ↓
physical UART 30
       ↓
LArPix-v3 root
       ↓
valid CONFIG_READ reply
```

---

# 15. Consequence for the CERN software design

The earlier high-level mixed-ASIC architecture still stands.

Each PACMAN is homogeneous:

```text
one PACMAN = one ASIC family
```

Therefore each control/config process can still use one fixed:

```text
PACMAN_IO(asic_version=2)
```

or:

```text
PACMAN_IO(asic_version=3)
```

depending on that PACMAN.

Hijinks mapping is independent of ASIC packet family.

The software should preserve:

```text
logical IO channels 1–40
```

at the DAQ/controller level while using the Hijinks mapping only for low-level physical-UART register operations such as:

```text
RX enable mask
UART clock ratio
packet delay
```

The logical channel should remain attached to data and chip identity.

---

# 16. Raw DAQ architecture remains unchanged

Nothing discovered here requires changing the proposed raw-acquisition architecture.

The first-pass CERN mixed-family design should still be:

```text
PACMAN v2d control process
PACMAN v3 control process
        │
        ├── PACMAN data server
        └── PACMAN data server
                 ↓
          one raw recorder
                 ↓
    parsing disabled during acquisition
                 ↓
            raw HDF5
                 ↓
      preserve source io_group
                 ↓
     offline family-aware decode
```

The distinction remains:

```text
CONFIG packets:
    v2d and v3 wire format compatible

DATA packets:
    v2d and v3 formats differ
```

Therefore raw acquisition should remain ASIC-agnostic, while decoding is family-aware.

---

# 17. Current software/hardware state at stopping point

PACMAN #66:

```text
IP:        192.168.0.102
io_group:  2
ASIC:      v3
firmware:  2.8
tile:      10

VDDD_DAC:  28000
VDDA_DAC:  52000

tile mask: 0x00000200
power:     enabled
MCLK:      enabled
```

Approximate loaded readback:

```text
VDDA ≈ 2.148 V
IDDA ≈ 814–817 mA

VDDD ≈ 1.227 V
IDDD ≈ 497–499 mA
```

The successful diagnostic leaves PACMAN RX disabled on exit:

```text
0x201c = 0xffffffff
```

but does not power the tile down.

Before leaving the bench unattended, use the Rev5 power-off tool if desired:

```text
~/cern-coldbox/scratch/pacman-tests/power_off_rev5.py
```

---

# 18. Recommended next development session

The next session should start from this known-good primitive rather than going back to the earlier read-only probe.

Suggested progression:

```text
1. Reproduce successful channel-37 bootstrap/read.

2. Repeat on logical channels:
       38 -> physical UART 31
       39 -> physical UART 32

   Do not expect channel 40 to work under Hijinks.

3. Read several additional configuration registers from the root.

4. Perform a controlled write/readback round trip:
       choose a harmless configuration register
       record old value
       write new value
       read it back
       restore original value

5. Establish the root's intended permanent chip ID.

6. Begin minimal root configuration using the real v3 donor sequence.

7. Put the v3 ASIC/tile into a known quiet/pedestal configuration.

8. Verify valid DATA packets can be produced and decoded.

9. Locate the v2d tile on PACMAN #67.

10. Repeat the same primitive validation for:
       PACMAN_IO(asic_version=2)
       Configuration_v2d / Packet_v2

11. Once both single-family PACMAN paths work independently,
    return to the mixed CERN orchestration implementation.
```

The key principle for the next session should remain:

```text
small, reversible hardware tests
→ understand the primitive
→ reproduce it
→ only then integrate it into crs_daq
```

---

# 19. Updated milestone status

```text
[✓] Freeze software baselines

[✓] Verify v2d/v3 CONFIG packet wire equality

[✓] Verify PACMAN command-server connectivity

[✓] Verify Rev5 register read/write

[✓] Verify Rev5 tile power control/readback

[✓] Understand Hijinks logical 40 -> physical 32 UART mapping

[✓] Find physical v3 tile connection

[✓] Bootstrap one v3 root ASIC

[✓] Obtain exact valid v3 CONFIG_READ reply

[ ] Reproduce on remaining live v3 root links

[ ] Controlled v3 configuration write/read

[ ] v3 pedestal/data mode

[ ] Locate v2d tile

[ ] Bootstrap/read v2d root

[ ] Full root assignment

[ ] Hydra networking

[ ] CERN per-PACMAN family dispatch

[ ] Concurrent v2d + v3 configuration

[ ] Aggregate raw acquisition

[ ] Offline mixed-family decode
```

The important milestone achieved on September 8, 2026 is therefore:

> **A Rev5 PACMAN running Hijinks successfully communicated through logical DAQ channel 37 / physical UART 30 with a real LArPix-v3 root ASIC on the CERN bench, including configuration writes required to bootstrap the return path and an exact, valid chip-ID configuration-read reply.**

This validates the central low-level control assumptions needed for the CERN mixed-LArPix software effort.