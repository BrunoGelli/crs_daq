# CERN Coldbox Mixed LArPix v2d / v3a Software Context

**Project:** CERN Coldbox LArPix test  
**Scope:** Simultaneous control and raw acquisition from LArPix-v2d and LArPix-v3a tiles  
**PACMAN hardware:** Rev5  
**PACMAN firmware/software target:** Hijinks  
**Primary software repositories:** `larpix-control` and `crs_daq`

## 1. Executive summary

The CERN coldbox charge readout will contain both **LArPix-v2d** and **LArPix-v3a** ASICs connected through multiple **PACMAN Rev5** boards.

The key simplifying hardware invariant is:

> **A single PACMAN will never serve a mixture of v2d and v3a ASICs. Each PACMAN belongs to exactly one ASIC family.**

This means the system does **not** need one monolithic `larpix.Controller` or one parsed `PACMAN_IO` instance that simultaneously understands both packet families during configuration.

The preferred architecture is therefore:

- one homogeneous control/configuration process per PACMAN;
- all PACMAN processes launched together by the top-level CRS workflow;
- one raw acquisition process connected to all PACMAN data servers;
- no ASIC-payload decoding in the acquisition loop;
- offline decoding selected by `io_group -> ASIC family`.

This is close to the existing 2x2 operating model and should allow a relatively small, targeted implementation.

---

## 2. Hardware organization

Expected system scale is approximately:

- 6 PACMANs;
- ~60 tiles total;
- roughly 20 v2d tiles;
- roughly 40 v3a tiles.

The exact tile count is not architecturally important. The essential constraint is:

```text
PACMAN 1 -> one ASIC family only
PACMAN 2 -> one ASIC family only
...
PACMAN 6 -> one ASIC family only
```

For example only:

```text
PACMAN / IOG 1 -> v2d
PACMAN / IOG 2 -> v2d
PACMAN / IOG 3 -> v3a
PACMAN / IOG 4 -> v3a
PACMAN / IOG 5 -> v3a
PACMAN / IOG 6 -> v3a
```

The real mapping must live in configuration rather than in source-code assumptions.

---

## 3. Firmware scope

For the first CERN implementation, the PACMAN platform is explicitly:

- **Rev5 PACMAN**
- **Hijinks**

The older 2x2 deployment used Rev3 / Rev4 PACMANs, so its low-level PACMAN register handling is **not** the hardware reference for CERN.

The `v3_10x16` and FSD branches are more relevant for:

- Rev5 register addresses;
- UART receive enable / disable behavior;
- logical IO-channel to UART mapping;
- packet-delay handling;
- Rev5-specific PACMAN operations.

### Zipline

Zipline support is **out of scope for the first implementation**. If CERN later migrates from Hijinks to Zipline, the PACMAN message-format / transport layer can be handled separately.

---

## 4. Software baselines

### 4.1 `larpix-control`

Repository: `https://github.com/larpix/larpix-control`  
Recommended branch: `release`  
Inspected release commit: `5a69050422e82356c8faf9ad0ea3168c322d63e8`

This branch already contains:

- `Configuration_v2d`
- `Configuration_v3`
- `Packet_v2`
- `Packet_v3`
- v2d/v3-aware `Chip` construction
- explicit HDF5 format versions for v2 and v3
- explicit packet-version selection in the PACMAN message formatter.

Important terminology:

```text
ASIC configuration version "2d" -> Packet_v2 -> PACMAN packet version 2
ASIC configuration version 3    -> Packet_v3 -> PACMAN packet version 3
```

### 4.2 `crs_daq` high-level base

Repository: `https://github.com/larpix/crs_daq`  
Preferred workflow base: `2x2-run3-cooldown`  
Inspected commit: `3ccef841f1639f7199063530e485ddbbcd4b338c`

Why keep it as the base:

- the collaboration already knows the 2x2 workflow;
- `RUN_CONFIG.json` organization is familiar;
- network/configure/run scripts are established;
- configuration archiving and metadata handling already exist;
- the top-level scripts already launch multiple control jobs in parallel.

Its old Rev3/Rev4 PACMAN layer should not be used as the CERN hardware reference.

### 4.3 Rev5/Hijinks donor branch

Branch: `v3_10x16`  
Inspected commit: `4a8b40f1abdcdbf3f66a75b7bb48f3259a3c12b9`

Use this as the principal donor/reference for:

- Rev5 PACMAN behavior;
- v3 networking;
- v3 configuration support;
- Rev5 UART mapping;
- Rev5 RX enable/disable registers.

### 4.4 v2d donor/reference branch

Branch: `fsd-run-delay`  
Inspected commit: `a020244ba774bd9be1bbbd850b423dc320a0d700`

Use this as an additional donor/reference for v2d networking and v2d-specific CRS behavior.

---

## 5. LArPix v2d and v3 configuration packets

This is the most important compatibility observation.

### 5.1 Common wire format

The v2d and v3 datasheets define the same 64-bit configuration packet structure:

```text
bits [1:0]   packet declaration
              10 = configuration write
              11 = configuration read
bits [9:2]   chip ID
bits [17:10] register address
bits [25:18] register data
bits [57:26] magic number = 0x89504E47
bit  [62]    downstream marker
bit  [63]    odd parity
```

The same magic word is used by both ASIC families: `0x89504E47`.

The same layout is reflected in `larpix-control`: both `Packet_v2` and `Packet_v3` use the same register-address, register-data, and magic-word bit slices.

### 5.2 Consequence for PACMAN

From the PACMAN/Hijinks transport point of view, a configuration command is an 8-byte ASIC payload sent on a UART.

Therefore:

> **PACMAN does not need to understand whether the configuration payload is for v2d or v3.**

The ASIC family matters when software decides which register exists, which register address to use, and how register bits are constructed. That belongs to `Chip`, `Configuration_v2d`, and `Configuration_v3`.

Once the final 64-bit configuration packet exists, the PACMAN transport can transmit it identically.

### 5.3 Configuration read replies

Configuration-read replies use the same configuration-packet wire layout. The software still needs to know which ASIC register map it is comparing against, but the raw reply structure is common.

**Datasheet references:**

- `LArPix-v2d Datasheet`, configuration packet table on pages 56–57.
- `LArPix-v3 Datasheet`, configuration packet table on pages 64–65.

---

## 6. Data packets are not compatible

Configuration packets are common, but normal data packets are not.

### LArPix-v2d

The provided v2d datasheet describes:

- packet declaration `00` for data;
- 32-bit timestamp field before optional repurposing;
- 8-bit ADC value;
- no v3 CDS fields.

### LArPix-v3

The provided v3 datasheet describes:

- packet declaration `01` for data;
- 28-bit timestamp field in the detailed packet table;
- 10-bit ADC value;
- reset-sample and CDS flags;
- additional v3 diagnostics/features.

Therefore a common live decoder cannot simply interpret all payloads as `Packet_v2` or all as `Packet_v3`.

This distinction matters only when decoding ASIC payloads. It does **not** prevent mixed raw recording.

**Datasheet references:**

- v2d data packet table: pages 55–56.
- v3 data packet table: pages 63–64.

---

## 7. Why a mixed parsed `PACMAN_IO` is not required for control

The current `larpix-control/release` `PACMAN_IO` constructor requires one packet family per instance:

```python
PACMAN_IO(..., asic_version=2)
```

or:

```python
PACMAN_IO(..., asic_version=3)
```

The packet formatter also checks that outgoing Python packet objects match that selected family.

That would be a problem if one process attempted to configure v2d and v3 chips simultaneously. The CERN hardware partition removes the need to do that.

The existing 2x2 operating model already launches separate Python processes for separate PACMAN groups. We should preserve this pattern.

The CERN control model becomes:

```text
top-level network/configure command
    |
    +-- PACMAN 1 process
    |      homogeneous v2d
    |      PACMAN_IO(asic_version=2)
    |
    +-- PACMAN 2 process
    |      homogeneous v2d
    |      PACMAN_IO(asic_version=2)
    |
    +-- PACMAN 3 process
    |      homogeneous v3a
    |      PACMAN_IO(asic_version=3)
    |
    +-- PACMAN 4 process
    |      homogeneous v3a
    |      PACMAN_IO(asic_version=3)
    |
    +-- ...
```

This gives the operator simultaneous system-wide configuration without requiring a mixed packet parser inside one control process.

---

## 8. Existing CRS_DAQ workflow already matches this process model

The 2x2 top-level scripts already launch independent jobs in the background.

For CERN, the cleanest form is one PACMAN per config file:

```text
io/pacman_iog1.json
io/pacman_iog2.json
io/pacman_iog3.json
io/pacman_iog4.json
io/pacman_iog5.json
io/pacman_iog6.json
```

Each file contains exactly one `io_group` / IP pair.

This provides:

- unambiguous ASIC-family selection;
- failure isolation;
- independent logs;
- easy retries;
- no mixed packet parser in the control process.

---

## 9. Raw data acquisition

The normal `crs_daq` binary acquisition path does:

```python
c.io.disable_packet_parsing = True
c.io.enable_raw_file_writing = True
```

With parsing disabled, the acquisition loop does not convert ASIC payloads into `Packet_v2` or `Packet_v3`.

Instead, the raw writer stores complete PACMAN messages together with their source `io_group`.

So one raw file can naturally contain messages from both families:

```text
message from IOG 1 -> v2d PACMAN
message from IOG 3 -> v3a PACMAN
message from IOG 2 -> v2d PACMAN
message from IOG 4 -> v3a PACMAN
...
```

No ASIC-family interpretation is required in the high-rate acquisition path.

### Practical consequence

A single `record_data.py` instance can connect to all six PACMANs and write one raw HDF5 file.

Offline decoding later uses `io_group -> ASIC family` to choose:

- `Packet_v2` decoding for v2d;
- `Packet_v3` decoding for v3a.

### Current constructor quirk

The current `PACMAN_IO` still requires `asic_version` even if packet parsing will immediately be disabled.

`v3_10x16/record_data.py` currently supplies `asic_version=3`. For raw acquisition this can remain temporarily because the packet version is not used to decode data once parsing is disabled.

A later cleanup could allow raw-only `PACMAN_IO(..., asic_version=None)`, but it is not required for the first working CERN system.

### Important limitation

Do **not** use mixed-family `record_data.py --packet` for the first implementation. The parsed HDF5 formats are family-specific.

---

## 10. Rev5 / Hijinks PACMAN layer

The CERN implementation should use the Rev5/Hijinks register behavior from `v3_10x16` / FSD rather than the older 2x2 behavior.

One clear example is UART RX enable handling: the newer Rev5 code uses the Rev5 RX-control register model and includes a logical IO-channel to physical UART mapping. The old 2x2 code uses the earlier Rev3/Rev4 model.

Architecture decision:

> **2x2 provides the high-level workflow; `v3_10x16` / FSD provide the low-level Rev5/Hijinks PACMAN behavior.**

---

## 11. Networking

The relevant donor code already contains separate networking implementations:

```text
base/network_base_FSD.py       # v2d-oriented donor
base/network_base_FSD_v3.py    # v3 donor
```

The CERN `network_larpix.py` should dispatch according to `io_group_asic_version_[io_group]`:

```text
"2d" -> v2d networking path
3    -> v3 networking path
```

Each invocation of `network_larpix.py` should operate on only one PACMAN / one ASIC family.

This also avoids the existing `v3_10x16` limitation where a shared enforcement controller is hardcoded to `PACMAN_IO(..., asic_version=3)`.

---

## 12. Configuration enforcement

The same approach applies to `configure_larpix.py`.

Each invocation:

1. reads its one-PACMAN `pacman_config`;
2. determines the associated `io_group`;
3. looks up the ASIC family in `RUN_CONFIG.json`;
4. maps that to packet version 2 or 3;
5. constructs a homogeneous `PACMAN_IO`;
6. loads the correct saved ASIC configurations;
7. performs normal enforcement/readback.

The existing configuration files already store ASIC-version metadata, and `config_loader` creates each `Chip` with that version. That behavior should be preserved.

---

## 13. Authoritative configuration mapping

`RUN_CONFIG.json` should contain the canonical ASIC-family assignment.

Example only:

```json
"io_group_asic_version_": {
    "1": "2d",
    "2": "2d",
    "3": 3,
    "4": 3,
    "5": 3,
    "6": 3
}
```

The actual CERN mapping must replace this example.

This mapping should also be archived with each run because it is required for deterministic offline decoding.

---

## 14. Terminology

### ASIC family / configuration class

Use:

```text
"2d"
3
```

when constructing LArPix `Chip` / configuration objects.

### PACMAN packet family

Use:

```text
2
3
```

when configuring the current `PACMAN_IO`.

Mapping:

```python
def packet_version(asic_version):
    if asic_version == "2d":
        return 2
    if asic_version == 3:
        return 3
    raise ValueError(...)
```

### v3a

The provided datasheet is a LArPix-v3 datasheet, and the software currently represents the family as `3`, not `"3a"`. Use the tested v3 software representation unless a v3a-specific software distinction is later identified.

---

## 15. Deliberately out of scope for the first pass

The first implementation should **not** become a broad DAQ rewrite.

Out of scope:

- Zipline support;
- mixed live decoded `PACMAN_IO`;
- automatic ASIC-family inference from arbitrary data payloads;
- a universal mixed v2/v3 parsed HDF5 schema;
- broad cleanup of unrelated legacy CRS helpers;
- generalized support for mixed ASIC families behind one PACMAN.

---

## 16. Source-backed caution points

### v3 dynamic/statistics registers

LArPix-v3 exposes changing statistics through configuration registers, including FIFO high-water occupancy, total packets, and dropped packets. Full configuration enforcement may eventually need to distinguish dynamic/statistical registers from static settings.

### v2d external trigger / sync settings

The v2d datasheet explicitly lists `enable_external_trigger` and `enable_external_sync` in register 123. The current software representation should be checked carefully if those features are needed immediately.

### Parsed HDF5

The current parsed HDF5 formats are not a common mixed-family schema. Raw acquisition avoids this issue entirely.

---

## 17. Canonical CERN architecture

```text
                       CERN operator workflow
                               |
               +---------------+---------------+
               |                               |
       control/config plane               raw data plane
               |                               |
      one process per PACMAN             one record_data.py
               |                               |
       +-------+-------+                       |
       |       |       |                       |
      v2d     v2d     v3a ...         all PACMAN dataservers
       |       |       |                       |
   Packet_v2 Packet_v2 Packet_v3               |
       |       |       |                       |
   PACMAN_IO PACMAN_IO PACMAN_IO               |
   asic=2    asic=2    asic=3                  |
       |       |       |                       |
     Rev5 Hijinks PACMANs  --------------------+
                                               |
                                       parsing disabled
                                               |
                                         raw HDF5
                                               |
                                  io_group retained per message
                                               |
                                      offline decoding
                                      /              \
                                   v2d                v3a
                                Packet_v2          Packet_v3
```

---

## 18. Definition of success

The CERN mixed-family architecture is validated when:

1. one top-level networking command launches all PACMAN networking jobs;
2. v2d and v3a networks initialize concurrently;
3. one top-level configuration command launches all PACMAN configuration jobs;
4. configuration readback/enforcement succeeds for both ASIC families;
5. one raw `record_data.py` process receives messages from every PACMAN;
6. one raw HDF5 file contains all PACMAN streams with correct `io_group` metadata;
7. offline decoding by `io_group` yields valid v2d and v3 data;
8. failure/retry of one PACMAN remains local to that PACMAN/process;
9. all PACMAN hardware control uses Rev5/Hijinks semantics.

---

## 19. Primary references

### Datasheets supplied with this project

- **LArPix-v2d Datasheet**
  - configuration register map;
  - Hydra bring-up;
  - data packet table, pages 55–56;
  - configuration packet table, pages 56–57.

- **LArPix-v3 Datasheet**
  - v3 changes;
  - configuration register map;
  - FIFO statistics;
  - data packet table, pages 63–64;
  - configuration packet table, pages 64–65.

### GitHub

- `larpix/larpix-control`, `release`
  - `larpix/chip.py`
  - `larpix/packet/packet_v2.py`
  - `larpix/packet/packet_v3.py`
  - `larpix/io/pacman_io.py`
  - `larpix/format/pacman_msg_format.py`
  - `larpix/format/rawhdf5format.py`

- `larpix/crs_daq`, `2x2-run3-cooldown`
  - `RUN_CONFIG.json`
  - `network_larpix.py`
  - `configure_larpix.py`
  - `record_data.py`
  - `run/network.sh`
  - `run/configure.sh`

- `larpix/crs_daq`, `v3_10x16`
  - `base/pacman_base.py`
  - `configure_pacman.py`
  - `base/network_base_FSD.py`
  - `base/network_base_FSD_v3.py`
  - `network_larpix.py`
  - `configure_larpix.py`
  - `record_data.py`

- `larpix/crs_daq`, `fsd-run-delay`
  - v2d-specific networking/configuration reference.

---

## 20. Working design statement

> **Do not make the low-level control process mixed unless the hardware requires it. Keep each PACMAN control path homogeneous, orchestrate the different ASIC families at the CRS level, and keep the acquisition path raw and ASIC-agnostic.**

That is the smallest and most robust path to simultaneous v2d/v3a operation for the CERN Rev5/Hijinks coldbox test.
