#!/usr/bin/env python3

import argparse
import time
from larpix.io import PACMAN_IO

parser = argparse.ArgumentParser()
parser.add_argument("--config", required=True)
parser.add_argument("--io-group", type=int, required=True)
parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)
parser.add_argument(
    "--mask",
    type=lambda x: int(x, 0),
    required=True,
)
args = parser.parse_args()

io = PACMAN_IO(
    relaxed=True,
    config_filepath=args.config,
    asic_version=args.asic_version,
    timeout=2000,
)

try:
    old = io.get_reg(0x201c, io_group=args.io_group)
    print(f"old RX mask: 0x{old:08x}")

    io.set_reg(0x201c, args.mask, io_group=args.io_group)

    new = io.get_reg(0x201c, io_group=args.io_group)
    print(f"new RX mask: 0x{new:08x}")

    time.sleep(0.2)

finally:
    io.cleanup()
    io.join()
