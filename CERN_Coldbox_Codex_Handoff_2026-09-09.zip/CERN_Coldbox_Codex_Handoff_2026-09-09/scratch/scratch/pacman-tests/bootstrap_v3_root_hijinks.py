#!/usr/bin/env python3

import argparse
import time

from larpix import Controller, Key
from larpix.io import PACMAN_IO
from larpix.packet.packet_v3 import Packet_v3


LOGICAL_TO_PHYSICAL = {
     1: 1,   2: 2,   3: 3,   4: 4,
     5: 5,   6: 6,   7: 7,   8: 8,
     9: 9,  10:10,  11:11,  12:None,
    13:12,  14:13,  15:14,  16:None,
    17:15,  18:16,  19:17,  20:None,
    21:18,  22:19,  23:20,  24:None,
    25:21,  26:22,  27:23,  28:None,
    29:24,  30:25,  31:26,  32:None,
    33:27,  34:28,  35:29,  36:None,
    37:30,  38:31,  39:32,  40:None,
}


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--io-channel", type=int, required=True)

    args = parser.parse_args()

    iog = args.io_group
    logical = args.io_channel

    physical = LOGICAL_TO_PHYSICAL[logical]

    if physical is None:
        raise RuntimeError(
            f"logical channel {logical} is intentionally dead in Hijinks"
        )

    print("========================================")
    print("V3 HIJINKS ROOT BOOTSTRAP")
    print("========================================")
    print(f"io_group:          {iog}")
    print(f"logical channel:   {logical}")
    print(f"physical UART:     {physical}")
    print()

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=3,
        timeout=2000,
    )

    c = Controller()
    c.io = io

    try:

        #
        # Start quiet.
        #
        io.set_reg(
            0x201c,
            0xffffffff,
            io_group=iog,
        )

        print("RX mask initially: "
              f"0x{io.get_reg(0x201c, io_group=iog):08x}")

        #
        # v3 donor explicitly sets mapped PHYSICAL UART
        # clock ratio to 1.
        #
        print()
        print("=== PHYSICAL UART SETUP ===")

        ratio = io.set_uart_clock_ratio(
            physical,
            1,
            io_group=iog,
        )

        print(
            f"UART {physical} clock ratio -> "
            f"0x{ratio:08x}"
        )

        #
        # Packet delay is also indexed by PHYSICAL UART.
        #
        delay_reg = (
            0x03014
            + (physical - 1) * 0x1000
        )

        old_delay = io.get_reg(
            delay_reg,
            io_group=iog,
        )

        new_delay = (
            (old_delay & 0xff)
            | (0xff << 8)
        )

        io.set_reg(
            delay_reg,
            new_delay,
            io_group=iog,
        )

        print(
            f"UART {physical} delay "
            f"0x{delay_reg:05x}: "
            f"0x{old_delay:08x} "
            f"-> 0x{new_delay:08x}"
        )

        #
        # Fresh known ASIC state.
        #
        print()
        print("=== HARD RESET ===")

        io.reset_larpix(
            length=4096,
            io_group=iog,
        )

        time.sleep(0.1)

        #
        # The chip is still addressed on the LOGICAL channel.
        #
        key = Key(iog, logical, 1)

        c.add_chip(
            key,
            version=3,
            root=True,
        )

        cfg = c[key].config

        print(f"chip key: {key}")

        #
        # Bootstrap exactly the relevant root communication
        # settings from network_base_FSD_v3.
        #
        print()
        print("=== BOOTSTRAPPING ROOT COMMUNICATION ===")

        registers = []

        for uart in range(4):

            setattr(cfg, f"i_rx{uart}", 3)
            registers.append(f"i_rx{uart}")

            setattr(cfg, f"r_term{uart}", 7)
            registers.append(f"r_term{uart}")

            setattr(cfg, f"v_cm_lvds_tx{uart}", 5)
            registers.append(f"v_cm_lvds_tx{uart}")

        #
        # Donor writes these register groups twice.
        #
        for name in registers:
            c.write_configuration(key, name)

        for name in registers:
            c.write_configuration(key, name)

        cfg.enable_posi = [0, 0, 0, 1]

        c.write_configuration(
            key,
            "enable_posi",
        )
        c.write_configuration(
            key,
            "enable_posi",
        )

        cfg.i_tx_diff2 = 7

        c.write_configuration(
            key,
            "i_tx_diff2",
        )
        c.write_configuration(
            key,
            "i_tx_diff2",
        )

        cfg.tx_slices2 = 15

        c.write_configuration(
            key,
            "tx_slices2",
        )
        c.write_configuration(
            key,
            "tx_slices2",
        )

        #
        # THIS is the critical return path.
        #
        cfg.enable_piso_downstream = [0, 0, 1, 0]

        c.write_configuration(
            key,
            "enable_piso_downstream",
        )

        cfg.enable_piso_upstream = [0, 0, 0, 0]

        c.write_configuration(
            key,
            "enable_piso_upstream",
        )

        time.sleep(0.05)

        #
        # Now enable ONLY the mapped PHYSICAL receiver.
        #
        print()
        print("=== ENABLING RECEIVER ===")

        rx_mask = (
            0xffffffff
            & ~(1 << (physical - 1))
        )

        io.set_reg(
            0x201c,
            rx_mask,
            io_group=iog,
        )

        readback_mask = io.get_reg(
            0x201c,
            io_group=iog,
        )

        print(
            f"logical {logical} "
            f"-> physical {physical}"
        )

        print(
            f"RX mask: "
            f"0x{readback_mask:08x}"
        )

        time.sleep(0.05)

        #
        # Finally attempt a very specific readback.
        #
        print()
        print("=== CHIP-ID READBACK ===")

        chip_id_reg = list(
            cfg.register_map["chip_id"]
        )[0]

        c.reads = []

        c.read_configuration(
            key,
            chip_id_reg,
            timeout=0.5,
            connection_delay=0.01,
        )

        collection = c.reads[-1]

        packets = [
            p for p in collection
            if isinstance(p, Packet_v3)
        ]

        valid = [
            p for p in packets
            if p.has_valid_parity()
        ]

        matches = [
            p for p in valid
            if (
                p.packet_type
                == Packet_v3.CONFIG_READ_PACKET
                and p.io_group == iog
                and p.io_channel == logical
                and p.chip_id == 1
                and p.register_address
                == chip_id_reg
            )
        ]

        print(
            f"received Packet_v3: "
            f"{len(packets)}"
        )

        print(
            f"valid parity:       "
            f"{len(valid)}"
        )

        print(
            f"exact matches:      "
            f"{len(matches)}"
        )

        for p in matches:
            print()
            print("MATCH:")
            print(" ", p)

        if matches:
            print()
            print(
                "PASS: ROOT CHIP COMMUNICATION WORKS"
            )
        else:
            print()
            print(
                "NO EXACT ROOT-CHIP REPLY"
            )

            #
            # Print only vaguely interesting packets,
            # not 1600 lines of noise.
            #
            interesting = [
                p for p in valid
                if (
                    p.chip_id == 1
                    or p.register_address
                    == chip_id_reg
                )
            ]

            print(
                f"interesting valid packets: "
                f"{len(interesting)}"
            )

            for p in interesting[:20]:
                print(" ", p)

    finally:

        #
        # Leave RX quiet.
        #
        try:
            io.set_reg(
                0x201c,
                0xffffffff,
                io_group=iog,
            )
        except Exception:
            pass

        io.cleanup()
        io.join()


if __name__ == "__main__":
    main()
