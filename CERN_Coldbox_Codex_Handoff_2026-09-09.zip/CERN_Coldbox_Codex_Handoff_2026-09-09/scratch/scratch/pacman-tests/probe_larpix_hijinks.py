#!/usr/bin/env python3

import argparse
import time

from larpix import Controller, Key
from larpix.io import PACMAN_IO
from larpix.packet.packet_v2 import Packet_v2
from larpix.packet.packet_v3 import Packet_v3


RESET_CYCLES = 4096


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)
    parser.add_argument("--io-channel", type=int, required=True)
    parser.add_argument("--chip-id", type=int, default=1)
    parser.add_argument("--timeout", type=float, default=0.2)

    args = parser.parse_args()

    chip_version = "2d" if args.asic_version == 2 else 3
    Packet = Packet_v2 if args.asic_version == 2 else Packet_v3

    iog = args.io_group
    ioc = args.io_channel

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=args.asic_version,
        timeout=2000,
    )

    c = Controller()
    c.io = io

    try:

        print("=== HIJINKS DIRECT CHANNEL PROBE ===")
        print(f"io_group:      {iog}")
        print(f"io_channel:    {ioc}")
        print(f"ASIC version:  {chip_version}")
        print(f"chip ID:       {args.chip_id}")
        print()

        print("PACMAN ping:", io.ping(io_group=iog))

        print(
            f"tile mask:    "
            f"0x{io.get_reg(0x10, io_group=iog):08x}"
        )

        print(
            f"global power: "
            f"0x{io.get_reg(0x14, io_group=iog):08x}"
        )

        print(
            f"MCLK:         "
            f"0x{io.get_reg(0x101c, io_group=iog):08x}"
        )

        #
        # Do NOT:
        #
        #   set_uart_clock_ratio()
        #   write packet-delay registers
        #   write 0x201c
        #
        # Those belong to the old/temporary UART register model.
        #

        print()
        print("=== HARD RESET ===")

        io.set_reg(0x1014, RESET_CYCLES, io_group=iog)

        clk_ctrl = io.get_reg(0x1010, io_group=iog)

        io.set_reg(
            0x1010,
            clk_ctrl | 4,
            io_group=iog
        )

        io.set_reg(
            0x1010,
            clk_ctrl,
            io_group=iog
        )

        time.sleep(0.1)

        key = Key(
            iog,
            ioc,
            args.chip_id
        )

        c.add_chip(
            key,
            version=chip_version,
            root=True
        )

        chip_id_reg = list(
            c[key].config.register_map["chip_id"]
        )[0]

        print()
        print(
            f"Sending CONFIG READ directly to "
            f"io_channel={ioc}, chip=1, reg={chip_id_reg}"
        )

        c.read_configuration(
            key,
            chip_id_reg,
            timeout=args.timeout,
            connection_delay=0.01,
        )

        collection = c.reads[-1]

        print()
        print(f"Received {len(collection)} parsed packets")

        found = False

        for packet in collection:

            # Ignore timestamp/sync/etc.
            if not isinstance(packet, Packet):
                continue

            print(" ", packet)

            if (
                packet.packet_type == Packet.CONFIG_READ_PACKET
                and packet.io_group == iog
                and packet.io_channel == ioc
                and packet.chip_id == args.chip_id
                and packet.register_address == chip_id_reg
                and packet.has_valid_parity()
            ):
                found = True

                print()
                print("MATCH!")
                print(
                    f"chip={packet.chip_id} "
                    f"register={packet.register_address} "
                    f"value={packet.register_data}"
                )

        print()

        if found:
            print("PASS: valid root-chip reply")
        else:
            print("NO VALID ROOT-CHIP REPLY")

    finally:
        io.cleanup()
        io.join()


if __name__ == "__main__":
    main()
