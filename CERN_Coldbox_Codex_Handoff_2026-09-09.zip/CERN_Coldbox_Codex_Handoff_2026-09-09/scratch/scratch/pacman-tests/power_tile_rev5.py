#!/usr/bin/env python3

import argparse
import time

from larpix.io import PACMAN_IO


def read_power(io, iog, tile):
    offset = tile - 1

    vdda = io.get_reg(0x24030 + offset, io_group=iog)
    vddd = io.get_reg(0x24040 + offset, io_group=iog)
    idda_raw = io.get_reg(0x24050 + offset, io_group=iog)
    iddd_raw = io.get_reg(0x24060 + offset, io_group=iog)

    print(
        f"Tile {tile}: "
        f"VDDA={vdda} mV  "
        f"IDDA={idda_raw / 4:.2f} mA  "
        f"VDDD={vddd} mV  "
        f"IDDD={iddd_raw / 4:.2f} mA"
    )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)

    parser.add_argument("--tile", type=int, default=1)
    parser.add_argument("--vdda-dac", type=int, required=True)
    parser.add_argument("--vddd-dac", type=int, required=True)

    args = parser.parse_args()

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=args.asic_version,
        timeout=2000,
    )

    tile = args.tile
    iog = args.io_group
    offset = tile - 1

    vdda_reg = 0x24010 + offset
    vddd_reg = 0x24020 + offset

    try:
        print("=== INITIAL STATE ===")
        print(f"tile mask: 0x{io.get_reg(0x10, io_group=iog):08x}")
        print(f"global power: 0x{io.get_reg(0x14, io_group=iog):08x}")
        print(f"MCLK: 0x{io.get_reg(0x101c, io_group=iog):08x}")
        read_power(io, iog, tile)

        print()
        print("=== SETTING MCLK ===")
        io.set_reg(0x101c, 0x4, io_group=iog)

        print("=== ENABLING PACMAN POWER ===")
        io.set_reg(0x14, 1, io_group=iog)

        print("=== ZEROING TILE DACS ===")
        io.set_reg(vddd_reg, 0, io_group=iog)
        io.set_reg(vdda_reg, 0, io_group=iog)
        time.sleep(0.2)

        print("=== PROGRAMMING TILE DACS ===")
        print(f"VDDD DAC = {args.vddd_dac}")
        print(f"VDDA DAC = {args.vdda_dac}")

        # donor does VDDD first
        io.set_reg(vddd_reg, args.vddd_dac, io_group=iog)
        io.set_reg(vdda_reg, args.vdda_dac, io_group=iog)

        print("=== ENABLING TILE ===")
        old_mask = io.get_reg(0x10, io_group=iog)
        new_mask = old_mask | (1 << offset)

        io.set_reg(0x10, new_mask, io_group=iog)

        time.sleep(0.5)

        print()
        print("=== POWERED STATE ===")
        print(f"tile mask: 0x{io.get_reg(0x10, io_group=iog):08x}")
        print(f"global power: 0x{io.get_reg(0x14, io_group=iog):08x}")
        print(f"MCLK: 0x{io.get_reg(0x101c, io_group=iog):08x}")

        read_power(io, iog, tile)

        print()
        print("Tile left powered for the next test.")

    finally:
        io.cleanup()
        io.join()


if __name__ == "__main__":
    main()
