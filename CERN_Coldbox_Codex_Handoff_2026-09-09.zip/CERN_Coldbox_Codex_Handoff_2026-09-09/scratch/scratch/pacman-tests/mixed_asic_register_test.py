#!/usr/bin/env python3

import time
import larpix
import larpix.io
from larpix.key import Key

TARGETS = [
    {
        "name": "PACMAN67 / v2d",
        "pacman_config": "/home/bgelli/cern-coldbox/configs/pacman67_v2d.json",
        "packet_version": 2,
        "chip_version": "2d",
        "io_group": 1,
        "io_channel": 27,
        "chip_id": 101,
        "physical_uart": 23,
        "expected_hit_veto_reg": 128,
        "expected_monitor_enable_reg": 118,
        "expected_monitor_chan_reg": 119,
    },
    {
        "name": "PACMAN66 / v3",
        "pacman_config": "/home/bgelli/cern-coldbox/configs/pacman66_v3.json",
        "packet_version": 3,
        "chip_version": 3,
        "io_group": 2,
        "io_channel": 37,
        "chip_id": 1,
        "physical_uart": 30,
        "expected_hit_veto_reg": 128,
        "expected_monitor_enable_reg": 114,
        "expected_monitor_chan_reg": 115,
    },
]


def read_register(c, key, reg, timeout=0.5):
    c.reads = []
    c.read_configuration(
        key,
        registers=reg,
        timeout=timeout,
        connection_delay=0.1,
    )
    if not c.reads:
        raise RuntimeError(f"{key}: controller received no read collection")

    matches = []
    for pkt in c.reads[-1]:
        if not hasattr(pkt, "register_address"):
            continue
        if pkt.packet_type != pkt.CONFIG_READ_PACKET:
            continue
        if pkt.io_group != key.io_group:
            continue
        if pkt.io_channel != key.io_channel:
            continue
        if pkt.chip_id != key.chip_id:
            continue
        if pkt.register_address != reg:
            continue
        if not pkt.has_valid_parity():
            continue
        matches.append(pkt)

    if not matches:
        print("\nObjects received:")
        for pkt in c.reads[-1]:
            print(" ", pkt)
        raise RuntimeError(
            f"{key}: no valid CONFIG_READ reply for ASIC register {reg}"
        )

    pkt = matches[-1]
    print(
        f"  READ ASIC reg {reg:3d} -> 0x{pkt.register_data:02x}   "
        f"packet={type(pkt).__name__}   raw={pkt.bytes().hex()}"
    )
    return pkt.register_data


def sync_config_register(cfg, reg, value):
    cfg.from_dict_registers({reg: value}, endian="little")


def write_register_from_config(c, key, reg):
    c.write_configuration(key, registers=reg)
    c.write_configuration(key, registers=reg)
    time.sleep(0.05)


def test_target(t):
    print()
    print("=" * 72)
    print(t["name"])
    print("=" * 72)

    c = larpix.Controller()
    c.io = larpix.io.PACMAN_IO(
        relaxed=True,
        config_filepath=t["pacman_config"],
        asic_version=t["packet_version"],
    )

    key = Key(t["io_group"], t["io_channel"], t["chip_id"])
    c.add_chip(key, version=t["chip_version"])
    chip = c[key]
    cfg = chip.config

    hit_veto_reg = list(cfg.register_map["enable_hit_veto"])[0]
    monitor_enable_reg = list(cfg.register_map["digital_monitor_enable"])[0]
    monitor_chan_reg = list(cfg.register_map["digital_monitor_chan"])[0]

    print(f"chip key:                 {key}")
    print(f"ASIC config class:        {type(cfg).__name__}")
    print(f"PACMAN packet family:     {t['packet_version']}")
    print(f"enable_hit_veto:          ASIC reg {hit_veto_reg}")
    print(f"digital_monitor_enable:   ASIC reg {monitor_enable_reg}")
    print(f"digital_monitor_chan:     ASIC reg {monitor_chan_reg}")

    assert hit_veto_reg == t["expected_hit_veto_reg"]
    assert monitor_enable_reg == t["expected_monitor_enable_reg"]
    assert monitor_chan_reg == t["expected_monitor_chan_reg"]
    print("ASIC register-map assertions: PASS")

    old_rx_mask = c.io.get_reg(0x201c, io_group=t["io_group"])
    new_rx_mask = old_rx_mask & ~(1 << (t["physical_uart"] - 1))
    print(f"PACMAN RX mask: 0x{old_rx_mask:08x} -> 0x{new_rx_mask:08x}")
    c.io.set_reg(0x201c, new_rx_mask, io_group=t["io_group"])

    try:
        print("\n--- Shared ASIC register: enable_hit_veto ---")
        reg128 = read_register(c, key, hit_veto_reg)
        sync_config_register(cfg, hit_veto_reg, reg128)
        raw_hit_veto = (reg128 >> 6) & 0x1
        print(f"  register 128 byte       = 0x{reg128:02x}")
        print(f"  raw bit 6               = {raw_hit_veto}")
        print(f"  cfg.enable_hit_veto     = {cfg.enable_hit_veto}")
        if int(cfg.enable_hit_veto) != raw_hit_veto:
            raise RuntimeError(
                "larpix-control semantic decoding disagrees with raw register bit 6"
            )
        print("  semantic decode: PASS")

        print("\n--- Family-specific digital monitor enable register ---")
        monitor_enable_byte = read_register(c, key, monitor_enable_reg)
        sync_config_register(cfg, monitor_enable_reg, monitor_enable_byte)
        print(f"  cfg.digital_monitor_enable = {cfg.digital_monitor_enable}")
        if cfg.digital_monitor_enable:
            raise RuntimeError(
                "Digital monitor is already enabled. Refusing to change its channel selector."
            )
        print("  digital monitor safely disabled: PASS")

        print("\n--- Family-specific ASIC register WRITE/READ/RESTORE ---")
        original_byte = read_register(c, key, monitor_chan_reg)
        sync_config_register(cfg, monitor_chan_reg, original_byte)
        original_monitor_chan = int(cfg.digital_monitor_chan)
        test_monitor_chan = (original_monitor_chan + 1) % 64

        print("  semantic setting: digital_monitor_chan")
        print(f"  ASIC physical register: {monitor_chan_reg}")
        print(f"  original value: {original_monitor_chan}")
        print(f"  test value:     {test_monitor_chan}")

        cfg.digital_monitor_chan = test_monitor_chan
        write_register_from_config(c, key, monitor_chan_reg)
        new_byte = read_register(c, key, monitor_chan_reg)
        sync_config_register(cfg, monitor_chan_reg, new_byte)
        print(f"  decoded readback: {cfg.digital_monitor_chan}")
        if int(cfg.digital_monitor_chan) != test_monitor_chan:
            raise RuntimeError(
                f"WRITE/READ mismatch: requested {test_monitor_chan}, "
                f"received {cfg.digital_monitor_chan}"
            )
        print("  WRITE/READ PASS")

        print("\n--- Restoring original ASIC configuration ---")
        cfg.digital_monitor_chan = original_monitor_chan
        write_register_from_config(c, key, monitor_chan_reg)
        restored_byte = read_register(c, key, monitor_chan_reg)
        sync_config_register(cfg, monitor_chan_reg, restored_byte)
        print(f"  restored decoded value: {cfg.digital_monitor_chan}")
        if int(cfg.digital_monitor_chan) != original_monitor_chan:
            raise RuntimeError(
                f"RESTORE mismatch: expected {original_monitor_chan}, "
                f"received {cfg.digital_monitor_chan}"
            )
        print("  RESTORE PASS")
        print(f"\nPASS: {t['name']} ASIC register access works")

    finally:
        c.io.set_reg(0x201c, old_rx_mask, io_group=t["io_group"])
        c.io.cleanup()


def main():
    for target in TARGETS:
        test_target(target)
    print()
    print("=" * 72)
    print("PASS: BOTH ASIC FAMILIES READ / WRITE / RESTORE SUCCESSFULLY")
    print("=" * 72)


if __name__ == "__main__":
    main()
