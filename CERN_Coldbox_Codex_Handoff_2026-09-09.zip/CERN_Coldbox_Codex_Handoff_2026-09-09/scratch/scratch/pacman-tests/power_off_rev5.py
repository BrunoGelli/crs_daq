#!/usr/bin/env python3

import argparse
import time

from larpix.io import PACMAN_IO


def read_power(io, iog, tile):
    offset = tile - 1

    vdda = io.get_reg(0x24030 + offset, io_group=iog)
    vddd = io.get_reg(0x24040 + offset, io_group=iog)
    idda = io.get_reg(0x24050 + offset, io_group=iog) / 4
    iddd = io.get_reg(0x24060 + offset, io_group=iog) / 4

    print(
        f"Tile {tile:2d}: "
        f"VDDA={vdda:4d} mV  IDDA={idda:7.2f} mA  "
        f"VDDD={vddd:4d} mV  IDDD={iddd:7.2f} mA"
    )


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)

    parser.add_argument(
        "--tiles",
        type=int,
        nargs="+",
        default=list(range(1, 11)),
        help="PACMAN tiles to turn off; default: all 1-10",
    )

    args = parser.parse_args()

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=args.asic_version,
        timeout=2000,
    )

    iog = args.io_group
    tiles = args.tiles

    try:
        print("=== BEFORE ===")
        mask = io.get_reg(0x10, io_group=iog)

        print(f"tile mask:    0x{mask:08x}")
        print(f"global power: 0x{io.get_reg(0x14, io_group=iog):08x}")
        print(f"MCLK:         0x{io.get_reg(0x101c, io_group=iog):08x}")
        print(f"RX mask:      0x{io.get_reg(0x201c, io_group=iog):08x}")

        for tile in tiles:
            read_power(io, iog, tile)

        print()
        print("=== DISABLING TILE OUTPUTS ===")

        new_mask = mask

        for tile in tiles:
            new_mask &= ~(1 << (tile - 1))

        io.set_reg(0x10, new_mask, io_group=iog)
        time.sleep(0.2)

        print(f"new tile mask: 0x{new_mask:08x}")

        print()
        print("=== ZEROING VDDA/VDDD DACS ===")

        for tile in tiles:
            offset = tile - 1

            # Rev5 tile DAC registers
            io.set_reg(0x24020 + offset, 0, io_group=iog)  # VDDD
            io.set_reg(0x24010 + offset, 0, io_group=iog)  # VDDA

        time.sleep(0.2)

        # If nothing remains powered, return the whole PACMAN to
        # our known safe/quiescent state.
        if new_mask == 0:
            print()
            print("=== QUIESCING PACMAN ===")

            io.set_reg(0x201c, 0xffffffff, io_group=iog)
            io.set_reg(0x14, 0, io_group=iog)
            io.set_reg(0x101c, 0, io_group=iog)

        print()
        print("=== AFTER ===")

        print(
            f"tile mask:    "
            f"0x{io.get_reg(0x10, io_group=iog):08x}"
        )
        print(
            f"global power: "
            f"0x{io.get_reg(0x14, io_group=iog):08x}"
        )
        print(
            f"MCLK:         "
            f"0x{io.get_reg(0x101c, io_group=iog):08x}"
        )
        print(
            f"RX mask:      "
            f"0x{io.get_reg(0x201c, io_group=iog):08x}"
        )

        for tile in tiles:
            read_power(io, iog, tile)

        print()
        print("PASS: selected Rev5 tiles powered off")

    finally:
        io.cleanup()
        io.join()


if __name__ == "__main__":
    main()
