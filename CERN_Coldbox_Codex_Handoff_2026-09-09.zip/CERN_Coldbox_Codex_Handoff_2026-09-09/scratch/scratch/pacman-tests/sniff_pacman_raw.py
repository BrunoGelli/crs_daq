#!/usr/bin/env python3

import argparse
import time
import zmq

import larpix.format.pacman_msg_format as pmf


parser = argparse.ArgumentParser()
parser.add_argument("--ip", required=True)
parser.add_argument("--seconds", type=float, default=1.0)
args = parser.parse_args()

ctx = zmq.Context()
sock = ctx.socket(zmq.SUB)

sock.setsockopt(zmq.SUBSCRIBE, b"")
sock.setsockopt(zmq.RCVTIMEO, 200)

sock.connect(f"tcp://{args.ip}:5556")

end = time.time() + args.seconds

try:
    while time.time() < end:
        try:
            msg = sock.recv()
        except zmq.Again:
            continue

        header, words = pmf.parse_msg(msg)

        for word in words:
            if word[0] == "DATA":
                _, io_channel, receipt_ts, payload = word

                print(
                    f"DATA "
                    f"ch={io_channel:2d} "
                    f"ts={receipt_ts:10d} "
                    f"payload={payload.hex()}"
                )
            else:
                print(word)

finally:
    sock.close()
    ctx.term()
