#!/usr/bin/env python3

import argparse
import time

from larpix.io import PACMAN_IO


N_TILES = 10


def read_power(io, iog, tile):
    offset = tile - 1

    vdda = io.get_reg(0x24030 + offset, io_group=iog)
    vddd = io.get_reg(0x24040 + offset, io_group=iog)

    idda = io.get_reg(0x24050 + offset, io_group=iog) / 4
    iddd = io.get_reg(0x24060 + offset, io_group=iog) / 4

    return vdda, idda, vddd, iddd


def shutdown(io, iog):
    # Disable all UART receivers first
    io.set_reg(0x201c, 0xffffffff, io_group=iog)

    # Disconnect all tile power outputs
    io.set_reg(0x10, 0, io_group=iog)

    time.sleep(0.1)

    # Zero every Rev5 tile DAC
    for tile in range(1, N_TILES + 1):
        offset = tile - 1
        io.set_reg(0x24020 + offset, 0, io_group=iog)
        io.set_reg(0x24010 + offset, 0, io_group=iog)

    # Disable global power and MCLK
    io.set_reg(0x14, 0, io_group=iog)
    io.set_reg(0x101c, 0, io_group=iog)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)

    parser.add_argument("--vddd-dac", type=int, required=True)
    parser.add_argument("--vdda-dac", type=int, required=True)

    parser.add_argument("--settle", type=float, default=0.5)
    parser.add_argument("--samples", type=int, default=3)

    args = parser.parse_args()

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=args.asic_version,
        timeout=2000,
    )

    iog = args.io_group

    results = []

    try:
        print("=== RESETTING PACMAN POWER STATE ===")
        shutdown(io, iog)

        # We need global supply infrastructure and MCLK during the scan.
        io.set_reg(0x101c, 4, io_group=iog)
        io.set_reg(0x14, 1, io_group=iog)

        # Keep every UART disabled. This is a POWER scan only.
        io.set_reg(0x201c, 0xffffffff, io_group=iog)

        print()
        print("Scanning PACMAN tiles 1-10")
        print(
            f"VDDD DAC={args.vddd_dac}, "
            f"VDDA DAC={args.vdda_dac}"
        )
        print()

        for tile in range(1, N_TILES + 1):

            offset = tile - 1

            vddd_reg = 0x24020 + offset
            vdda_reg = 0x24010 + offset

            print(f"=== TILE {tile} ===")

            # Make absolutely sure no other tile is enabled
            io.set_reg(0x10, 0, io_group=iog)

            # Start this regulator pair at zero
            io.set_reg(vddd_reg, 0, io_group=iog)
            io.set_reg(vdda_reg, 0, io_group=iog)

            time.sleep(0.1)

            # Program known-good CERN values
            io.set_reg(vddd_reg, args.vddd_dac, io_group=iog)
            io.set_reg(vdda_reg, args.vdda_dac, io_group=iog)

            # Enable ONLY this tile
            mask = 1 << offset
            io.set_reg(0x10, mask, io_group=iog)

            time.sleep(args.settle)

            samples = []

            for _ in range(args.samples):
                sample = read_power(io, iog, tile)
                samples.append(sample)

                print(
                    f"  VDDA={sample[0]:4d} mV "
                    f"IDDA={sample[1]:7.2f} mA | "
                    f"VDDD={sample[2]:4d} mV "
                    f"IDDD={sample[3]:7.2f} mA"
                )

                time.sleep(0.15)

            avg_vdda = sum(x[0] for x in samples) / len(samples)
            avg_idda = sum(x[1] for x in samples) / len(samples)
            avg_vddd = sum(x[2] for x in samples) / len(samples)
            avg_iddd = sum(x[3] for x in samples) / len(samples)

            results.append(
                (tile, avg_vdda, avg_idda, avg_vddd, avg_iddd)
            )

            # Turn this tile off before moving on
            io.set_reg(0x10, 0, io_group=iog)

            time.sleep(0.1)

            io.set_reg(vddd_reg, 0, io_group=iog)
            io.set_reg(vdda_reg, 0, io_group=iog)

            time.sleep(0.1)

            print()

        print()
        print("==============================================")
        print("SUMMARY")
        print("==============================================")

        print(
            "Tile |   VDDA |    IDDA |   VDDD |    IDDD"
        )

        for tile, vdda, idda, vddd, iddd in results:
            print(
                f"{tile:4d} | "
                f"{vdda:6.0f} | "
                f"{idda:7.2f} | "
                f"{vddd:6.0f} | "
                f"{iddd:7.2f}"
            )

    finally:
        print()
        print("=== FINAL SAFE SHUTDOWN ===")

        try:
            shutdown(io, iog)
        finally:
            io.cleanup()
            io.join()


if __name__ == "__main__":
    main()
