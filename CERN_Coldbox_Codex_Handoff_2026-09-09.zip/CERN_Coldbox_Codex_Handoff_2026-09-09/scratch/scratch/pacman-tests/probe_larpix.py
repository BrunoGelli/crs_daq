#!/usr/bin/env python3

import argparse
import time

import larpix
from larpix import Controller, Key
from larpix.io import PACMAN_IO
from larpix.packet.packet_v2 import Packet_v2
from larpix.packet.packet_v3 import Packet_v3


RESET_CYCLES = 4096

# First four IO channels are also physical Rev5 UARTs 1..4.
# This first diagnostic is deliberately restricted to tile 1.
def io_channel_to_uart(io_channel):
    if io_channel not in (1, 2, 3, 4):
        raise ValueError(
            "Initial probe intentionally supports only tile-1 IO channels 1-4"
        )
    return io_channel


def main():
    parser = argparse.ArgumentParser(
        description="Probe one freshly reset LArPix root chip"
    )

    parser.add_argument("--config", required=True)
    parser.add_argument("--io-group", type=int, required=True)
    parser.add_argument("--asic-version", type=int, choices=(2, 3), required=True)
    parser.add_argument("--io-channel", type=int, default=1)
    parser.add_argument("--chip-id", type=int, default=1)
    parser.add_argument("--timeout", type=float, default=0.5)

    args = parser.parse_args()

    chip_version = "2d" if args.asic_version == 2 else 3
    Packet = Packet_v2 if args.asic_version == 2 else Packet_v3

    iog = args.io_group
    ioc = args.io_channel
    uart = io_channel_to_uart(ioc)

    tile = ((ioc - 1) // 4) + 1
    tile_bit = 1 << (tile - 1)

    print("LArPix root-chip probe")
    print(f"  config:          {args.config}")
    print(f"  io_group:        {iog}")
    print(f"  ASIC family:     {chip_version}")
    print(f"  PACMAN packet:   {args.asic_version}")
    print(f"  tile:            {tile}")
    print(f"  io_channel:      {ioc}")
    print(f"  physical UART:   {uart}")
    print(f"  target chip ID:  {args.chip_id}")
    print()

    io = PACMAN_IO(
        relaxed=True,
        config_filepath=args.config,
        asic_version=args.asic_version,
        timeout=2000,
    )

    c = Controller()
    c.io = io

    try:
        # ----------------------------------------------------------
        # 1. Verify PACMAN + tile state
        # ----------------------------------------------------------

        print("=== PACMAN STATE ===")

        if not io.ping(io_group=iog):
            raise RuntimeError("PACMAN did not respond to ping")

        tile_mask = io.get_reg(0x10, io_group=iog)
        global_power = io.get_reg(0x14, io_group=iog)
        mclk = io.get_reg(0x101C, io_group=iog)
        rx_enable = io.get_reg(0x201C, io_group=iog)

        print(f"tile mask:      0x{tile_mask:08x}")
        print(f"global power:   0x{global_power:08x}")
        print(f"MCLK:           0x{mclk:08x}")
        print(f"Rev5 RX mask:   0x{rx_enable:08x}")

        if not (tile_mask & tile_bit):
            raise RuntimeError(f"Tile {tile} is not enabled")

        if not global_power:
            raise RuntimeError("PACMAN global power is not enabled")

        if mclk != 4:
            print(f"WARNING: expected MCLK control 4, got {mclk}")

        # ----------------------------------------------------------
        # 2. Set up ONLY the required Rev5 UART timing
        # ----------------------------------------------------------

        print()
        print("=== UART SETUP ===")

        print(f"setting UART {uart} clock ratio -> 1")
        io.set_uart_clock_ratio(uart, 1, io_group=iog)

        # Rev5 donor packet-delay register:
        # UART1 -> 0x3014
        # UART2 -> 0x4014
        # ...
        packet_delay_reg = 0x3014 + (uart - 1) * 0x1000

        old_delay = io.get_reg(packet_delay_reg, io_group=iog)
        new_delay = (old_delay & 0xFF) | (0xFF << 8)

        print(
            f"packet delay reg 0x{packet_delay_reg:05x}: "
            f"0x{old_delay:08x} -> 0x{new_delay:08x}"
        )

        io.set_reg(packet_delay_reg, new_delay, io_group=iog)

        # ----------------------------------------------------------
        # 3. Hard reset LArPix
        # ----------------------------------------------------------

        print()
        print("=== LARPIX RESET ===")

        io.set_reg(0x1014, RESET_CYCLES, io_group=iog)

        clk_ctrl = io.get_reg(0x1010, io_group=iog)

        print(f"clock control before reset: 0x{clk_ctrl:08x}")

        io.set_reg(0x1010, clk_ctrl | 4, io_group=iog)
        io.set_reg(0x1010, clk_ctrl, io_group=iog)

        time.sleep(0.1)

        print(f"reset complete ({RESET_CYCLES} cycles)")

        # ----------------------------------------------------------
        # 4. Create the correct ASIC object
        # ----------------------------------------------------------

        key = Key(iog, ioc, args.chip_id)

        c.add_chip(
            key,
            version=chip_version,
            root=True,
        )

        print()
        print("=== CHIP OBJECT ===")
        print(f"key:          {key}")
        print(f"ASIC version: {c[key].asic_version}")

        # ----------------------------------------------------------
        # 5. Read one physical register and find its reply
        # ----------------------------------------------------------

        def read_register(register, label):
            print()
            print(
                f"READ {label}: register {register} "
                f"(0x{register:02x})"
            )

            c.read_configuration(
                key,
                register,
                timeout=args.timeout,
                connection_delay=0.01,
            )

            collection = c.reads[-1]

            matches = []

            for packet in collection:
                if not isinstance(packet, Packet):
                    continue

                if packet.packet_type != Packet.CONFIG_READ_PACKET:
                    continue

                if packet.io_group != iog:
                    continue

                if packet.io_channel != ioc:
                    continue

                if packet.chip_id != args.chip_id:
                    continue

                if packet.register_address != register:
                    continue

                matches.append(packet)

            if not matches:
                print("  NO MATCHING CONFIG-READ REPLY")

                print("  packets received:")
                for packet in collection:
                    print("   ", packet)

                return None

            for packet in matches:
                print(
                    f"  REPLY "
                    f"chip={packet.chip_id} "
                    f"reg={packet.register_address} "
                    f"data={packet.register_data} "
                    f"(0x{packet.register_data:02x}) "
                    f"parity_ok={packet.has_valid_parity()}"
                )

            return matches[-1].register_data

        # ----------------------------------------------------------
        # First prove basic communication using chip_id.
        # ----------------------------------------------------------

        chip_id_reg = list(
            c[key].config.register_map["chip_id"]
        )[0]

        result = read_register(
            chip_id_reg,
            "chip_id"
        )

        if result is None:
            print()
            print("FAIL: no reply from root chip")
            return

        print()
        print("SUCCESS: root chip replied!")

        # ----------------------------------------------------------
        # Only after chip_id succeeds, read a few more.
        # ----------------------------------------------------------

        print()
        print("=== ADDITIONAL REGISTER READS ===")

        names = [
            "threshold_global",
            "vref_dac",
            "csa_testpulse_dac",
        ]

        for name in names:
            if name not in c[key].config.register_map:
                print(f"{name}: not present for this ASIC")
                continue

            registers = list(c[key].config.register_map[name])

            for register in registers:
                read_register(register, name)

        print()
        print("PASS: ASIC configuration-read communication works")

    finally:
        io.cleanup()
        io.join()


if __name__ == "__main__":
    main()
