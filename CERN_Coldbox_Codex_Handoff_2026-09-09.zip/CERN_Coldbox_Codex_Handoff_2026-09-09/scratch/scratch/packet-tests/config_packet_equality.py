from larpix.packet.packet_v2 import Packet_v2
from larpix.packet.packet_v3 import Packet_v3


def make_config_packet(Packet):
    p = Packet()

    p.packet_type = Packet.CONFIG_WRITE_PACKET
    p.chip_id = 42
    p.register_address = 17
    p.register_data = 0x5A

    p.magic_word = 0x89504E47
    p.downstream_marker = 0

    p.assign_parity()

    return p


v2 = make_config_packet(Packet_v2)
v3 = make_config_packet(Packet_v3)

print("v2:", v2.bytes().hex())
print("v3:", v3.bytes().hex())

print("identical:", v2.bytes() == v3.bytes())

assert v2.bytes() == v3.bytes()

print("PASS")
